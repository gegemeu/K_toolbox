function [v,beta,P] = K_housec(x);
%K_HOUSEC Householder transformation

% x can be complex
% It zeroes the components from 2 to the last
% The result is x - beta (v' x) v

nx = length(x);
xi = x(1);
alpha = norm(x);
if alpha == 0 || xi == alpha
 v = zeros(nx,1);
 beta = 0;
 P = eye(nx,nx);
 return
end
v = (x - alpha * eye(nx,1)) / (xi - alpha);
beta = conj((alpha - xi) / alpha);
% Sending back P is optional
if nargout == 3
 P = eye(nx,nx) - beta * (v * v');
end % if nargout

