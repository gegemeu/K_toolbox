function [A,b,Dr,Uh,C] = K_presc_convGMRES(g,x0,nr0,lamb,V,Ritz);
%K_PRESC_CONVGMRES Matrix and right-hand side with a prescribed GMRES convergence

% g = prescribed relative residual norms
% nr0 = prescribed norm of the initial residual
% V = orthonormal matrix
% Ritz = Ritz values as columns
% A, b = matrix and right-hand side

% This works only for small matrices, Uh can be badly conditioned

% Compute the coefficients of the FOM residual polynomials from the Ritz values
n = length(g);
Xi = zeros(n,n-1);
for j = 1:n-1
 y = transpose(polynome(Ritz(1:j,j)));
 y = y / y(j+1);
 Xi(1:j+1,j) = y(j+1:-1:1);
end
Uh(2:n,2:n) = Xi(2:n,1:n-1);
Uh(1,1:n) = ones(1,n);
% inverses of FOM residual norms
rF = zeros(1,n);
rF(1) = 1 / g(1);
for j = 2:n
 rF(j) = sqrt(1 / g(j)^2 - 1 / g(j-1)^2);
end % for j
Dr = diag(1 ./ rF);
Dri = diag(rF);
% companion matrix of the eigenvalues of A
C = companionmat(lamb);
Y = (Uh \ C) * Uh;
Y = Dr * Y * Dri;
A = (V * Y) / V;
b = nr0 * V(:,1) + A * x0;
end % function

function C=companionmat(eigA);
n = length(eigA);
p = polynome(eigA);
C = zeros(n,n);
C(:,n) = -p(n+1:-1:2);
C(2:n,1:n-1) = eye(n-1);
end % function

function c=polynome(x);
n = length(x);
c = [1 zeros(1,n)];
for j=1:n
 c(2:(j+1)) = c(2:(j+1)) - x(j).*c(1:j);
end % for j
% The result should be real if the roots are complex conjugates
if isequal(sort(x(imag(x)>0)),sort(conj(x(imag(x)<0))))
 c = real(c);
end % if
end % function

