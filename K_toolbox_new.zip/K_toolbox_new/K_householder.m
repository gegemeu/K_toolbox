function [v,beta,P] = K_householder(x,m);
%K_HOUSEHOLDER Householder transformation

% x  must be real
% It zeroes the components from m to the last
% The result is x - beta (v' x) v

nx = length(x);
x = x(m-1:nx);
n = length(x);
sig = x(2:n)' * x(2:n);
v = [1; x(2:n)];
if sig == 0
 beta = 0;
else
 mu = sqrt(x(1)^2 + sig);
 if x(1) <= 0
  v(1) = x(1) - mu;
 else
  v(1) = -sig/(x(1) + mu);
 end % if x(1)
 beta = 2 * v(1)^2 / (sig + v(1)^2);
 v = v / v(1);
end % if sig
v = [zeros(m-2,1); v];
% Sending back P is optional
if nargout == 3
 P = speye(nx,nx) - beta * (v * v');
end % if nargout

