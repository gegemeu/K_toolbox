function [L,H,s] = K_Hessenberg(A,u,nitmax,piv);
%K_HESSENBERG Hessenberg basis

% there is a more efficient coding in K_CMRH

% A = matrix
% u = starting vector
% nitmax iterations
% partial pivoting if piv ~= 0, no pivoting if piv = 0 (dangerous!)
% L = basis vectors, H = upper Hessenberg matrix
% s = permutation vector

n = size(A,1);
nitmax = min(nitmax,n);
H = zeros(nitmax,nitmax);
L = zeros(n,nitmax);
s = [1:n]';
i0 = index(u,piv);
L(:,1) = u / u(i0);
s = swap(s,1,i0,piv);

for j = 1:nitmax
 w = A * L(:,j);
 for i = 1:j
  c = w(s(i));
  H(i,j) = c;
  w(s(i)) = 0;
  si = s(i+1:n);
  w(si) = w(si) - c * L(si,i);
 end % for i
 if j < nitmax
  sj = s(j+1:n);
  i1 = index(w(sj),piv);
  i0 = i1 + j;
  s = swap(s,j+1,i0,piv);
  H(j+1,j) = w(sj(i1));
  L(:,j+1) = w / H(j+1,j);
 end % if
end % for j
end % function

function s = swap(s,i,j,piv);
if piv == 0 
 return % no pivoting
else
 % swap components i and j
 ss = s(i);
 s(i) = s(j);
 s(j) = ss;
end % if
end % function

function i0 = index(u,piv);
if piv == 0
 i0 = 1; % no pivoting
else
 [y,I] = max(abs(u)); % find the pivot
 i0 = I(1);
end % if
end % function

