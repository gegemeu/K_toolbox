function [x,ni,resn] = K_Orthores(A,b,x0,epsi,nitmax);
%K_ORTHORES Orthores

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

n = size(A,1);
nb = norm(b);
x = x0;
r = b - A * x;
R = zeros(n,nitmax+1);
X = zeros(n,nitmax+1);
resn = zeros(1,nitmax+1);
rr = zeros(nitmax+1,1);
R(:,1) = r;
X(:,1) = x;
rr(1) = r' * r;
resn(1) = norm(r);
ni = 0;

for k = 1:nitmax
 ni = ni + 1;  % number of iterations
 Ar = A * r; % matrix vector product
 alpha = (Ar' * R(:,1:k))' ./ rr(1:k);
 beta = 1 / sum(alpha(1:k));
 gamma = beta * alpha;
 x = beta * r + X(:,1:k) * gamma;
 r = -beta * Ar + R(:,1:k) * gamma;
 R(:,k+1) = r;
 X(:,k+1) = x;
 rr(k+1) = r' * r;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end  % for k
resn = resn(1:ni+1);


