function [V,H] = K_Newton_RS(A,u,nitmax,pit);
%K_NEWTON_RS Newton basis using Reichel's spoke sets

% A = matrix
% u = starting vector for Arnoldi
% nitmax points
% pit iterations of Arnoldi
% V = basis vectors
% H = upper Hessenberg matrix
% if pit < 0, we (loosely) orthogonalize the basis

rng('default');
n = size(A,1);
m = nitmax;
cgs = 0;
if pit < 0
 cgs = 1;
 pit = -pit;
end % if
% pit iterations of Arnoldi
[VV,HH] = K_Arnoldi_MGS(A,u,pit);
HH = HH(1:pit,1:pit);
eigH = eig(full(HH)); % Ritz values
if isreal(eigH) % test if the eigenvalues are real
 % get fast Leja points on the interval
 zp = leja_shift(min(eigH),max(eigH),m+1);
else
 % Fast Leja points on spoke sets
 ds = compress_R(eigH);
 % first point
 [leja,cpts,scalefactor] = K_lejashifts_R(ds);
 % add p-1 points
 [leja,cpts] = K_lejashifts_R([],m-1,leja,cpts,scalefactor);
 shift = expand_R(leja);
 zp = shift;
end % if isreal
V = zeros(n,nitmax);
T = zeros(nitmax+1,nitmax);
u = u / norm(u); 
V(:,1) = u;
for j = 1:nitmax % number of steps
 compl = ~isreal(zp(j));
 s = real(zp(j));
 Av = A * V(:,j);
 w = Av;
 vv = w - s * V(:,j);
 nvv = norm(vv);
 V(:,j+1) = vv / nvv;
 T(j,j) = s;
 T(j+1,j) = nvv;
 if compl && j <= nitmax
  Av = A * V(:,j);
  w = Av;
  si2 = imag(zp(j))^2 ;
  vv = w - s * V(:,j) + (si2 / nvv) * V(:,j-1);
  nvv_old = nvv;
  nvv = norm(vv);
  V(:,j+1) = vv / nvv;
  T(j,j) = s;
  T(j+1,j) = nvv;
  T(j-1,j) = -si2 / nvv_old;
 end % if compl
end % for j
% Compute H
% loosely orthogonalize the basis?
if cgs == 1
 % use cholQR
 VV = V' * V;
 [R,msg] = chol(VV);
 if msg ~= 0
  % if cholQR fails, use CGS
  [V,R] = orth_cgsR(V(:,1:m+1));
 else
  V = V / R;
 end % if
 H = triu(R) * T(1:m+1,1:m);
else
 H = T(1:m+1,1:m);
end % if cgs
end % function

function z = leja_shift(a,b,n);
% shifted Leja points on [a,b]
% Leja points on [-2,2]
xleja = leja_points(n);
% shift
lm = (b - a) / 4;
lp = (a + b) / 2;
z = lp + lm * xleja;
end % function

function xleja = leja_points(n,varargin);
% computes the first n Leja points in [-2,2]
if nargin > 1
 x = varargin{1};
else
 x = 1;
end % if
if (length(x) > 1)
 xleja = leja_ord(x,n);
 return
end % if
options = optimset('fminbnd');
options = optimset('TolX',1e-15);
xleja = zeros(n,1);
xmaxloc = zeros(n-2,1);
fmaxloc = xmaxloc;
if x == 1
 xleja(1) = 2;
 xleja(2) = -2;
 xleja(3) = 0;
else
 xleja(1) = 0;
 xleja(2) = 2;
 xleja(3) = -2;
 n = n - (1 - mod(n,2));
end % if x
xsort = xleja;
for k = 4:x:n
 xsort = sort(xsort(1:k-1));
 for i = 1:(k-2)/x
  [xmaxloc(i),fmaxloc(i)] = fminbnd(@fleja,xsort(i),xsort(i+1),options,xleja,k-1);
 end % for i
 [fmax index] = max(-fmaxloc(1:k-2));
 xleja(k) = xmaxloc(index);
 xleja(k+1) = -xmaxloc(index);
 xsort(k) = xleja(k);
 xsort(k+1) = xleja(k+1);
end % for k
xleja = xleja(1:n);
end % function

function z = fleja(x,xleja,n)
% the opposite of the Leja function to maximize
z = -abs(prod(x - xleja(1:n)));
end

function z = leja_ord(x,n);
% Leja order of the first n components of the vector x
m = length(x);
n = min(n,m);
z = zeros(size(x));
[v index] = max(abs(x));
z(1) = x(index);
temp = abs(x - z(1));
[v index] = max(temp);
z(2) = x(index);
for k = 2:n-1
  for i = 1:m
    temp(i) = temp(i) * abs(x(i) - z(k));
  end % for i
  [v index] = max(temp);
  z(k+1) = x(index);
end % for k
z = z(1:n);
end % function

function shft = compress_R(d)
% Compresses complex d into array shft by skipping all the complex values with negative imaginary part
% code from L. Reichel
n = max(size(d));
shft = [] ;
for k = 1:n
 if imag(d(k)) == 0
  shft = [shft; [d(k),0]];
 elseif imag(d(k)) > 0
  shft = [shft; [real(d(k)),imag(d(k))]];
 end % if
end % for k
end % function

function d = expand_R(shft)
% Expands the array shft into complex d by completing all the
% conjugate pairs (by assumption, only non negative numbers are in shft)
% code from L. Reichel
n = max(size(shft));
d = [];
for k = 1:n
 d = [d; complex(shft(k,1),shft(k,2))] ;
 if shft(k,2) > 0
  d = [d; complex(shft(k,1),-shft(k,2))];
 end % if
end % for k
end % function

function [V,R] = orth_cgsR(A);
% orthogonalisation of the columns of A
% Classical Gram-Schmidt but returns only R
[m,n] = size(A);
V = zeros(m,n);
R = zeros(n,n);
v = A(:,1);
nv = norm(v);
V(:,1) = v / nv;
R(1,1) = nv;
% orthogonalization (once)
for k = 2:n
 w = A(:,k);
 v = w;
 for j=1:k-1
  alpha = w' * V(:,j);
  R(j,k) = alpha;
  v = v - alpha * V(:,j);
 end % for j
 nv = norm(v);
 R(k,k) = nv;
 if nv <= 1e-15
  fprintf('\n orth_cgsR: Breakdown, step %d \n\n',k)
  return
 end % if
 v = v / norm(v);
 V(:,k) = v;
end % for k
end % function



