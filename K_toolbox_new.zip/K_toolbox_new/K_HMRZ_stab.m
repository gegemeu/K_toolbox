function [x,ni,resn,nk,matvec] = K_HMRZ_stab(A,b,x0,w0,epsi,nitmax,varargin);
%K_HMRZ_STAB HMRZ Stab from Brezinski, Redivo-Zaglia and Sadok

% A, b = matrix and right-hand side
% x0 = starting vector
% w0 = shadow vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% varargin(1) = threshold for the jumps (1e-15 by default)
% varagin(2) = max jump (nitmax+1 by default)
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% nk = iterations with jumps
% matvec = number of matrix vector products

if nargin < 7
 epss = 1e-15;
else
 epss = varargin{1};
end % if
if length(varargin) < 2 || nargin < 7
 max_jump = nitmax + 1;
else
 max_jump = varargin{2};
end % if
nb = norm(b);
nA = size(A,1);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
matvec = zeros(1,nitmax+1);
nk = zeros(1,nitmax+1);
d = zeros(1,max_jump+1);
resn(1) = norm(r);
matv = 1;
matvec(1) = matv;
At = A';
if isempty(w0)
 w0 = randn(nA,1);
end % if
z1 = zeros(nA,1);
zt1 = z1;
z = r;
zt = w0;
c = 0;
b0 = 1;
ni = 0;

for k = 1:nitmax
 ni = ni + 1;
 d(1) = zt' * r;
 yt = At * zt; % matrix vector product with the transpose
 matv = matv + 1;
 ut = yt;
 b01 = b0;
 b0 = yt' * z;
 nz = norm(z);
 nynz = norm(yt) * nz;
 mk = 1;
 while (abs(b0) <= nynz * epss) && mk <= max_jump
  mk = mk + 1;
  d(mk) = yt' * r;
  yt = At * yt; % matrix vector product with the transpose
  matv = matv + 1;
  b0 = yt' * z;
  nynz = norm(yt) * nz;
 end % while
 if mk > max_jump
  error(' K HMRZ stab: The jump is too large')
 end % if
 nk(ni+1) = nk(ni) + mk;
 if k ~= 1
  c = b0 / b01;
 end % if k
 t = z;
 z_old = z;
 z = -c * z1;
 tt = zt;
 zt_old = zt;
 zt = -c * zt1;
 for i = 1:mk
  u = A * t;  %matrix vector product
  matv = matv + 1;
  beta = d(mk-i+1) / b0;
  x = x + beta * t;
  r = r - beta * u;
  gamma = -(yt' * u) / b0;
  t = u + gamma * z_old;
  if i ~= 1
   ut = At * tt;  % matrix vector product with the transpose
   matv = matv + 1;
  end % if i
  tt = ut + gamma * zt_old;
 end % for i
 z1 = z_old;
 zt1 = zt_old;
 z = z + t;
 zt = zt + tt;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 matvec(ni+1) = matv;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end  % for k
resn = resn(1:ni+1);
nk = nk(1:ni+1);
matvec = matvec(1:ni+1);






