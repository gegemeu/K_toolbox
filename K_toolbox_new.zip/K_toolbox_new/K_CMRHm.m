function [x,ni,nc,resn] = K_CMRHm(A,b,x0,m,epsi,nitmax);
%K_CMRHM Restarted CMRH

% A, b = matrix and right-hand side
% x0 = starting vector
% m = restart parameter
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% nc = number of cycles
% resn = residual norms (may be different from || b - A x_k ||)

if m < 1
 error(' K CMRHm: The restart parameter m has to be positive')
end
m = min(m,nitmax);
n = size(A,1);
rhs = zeros(nitmax+1,1);
resn = zeros(1,nitmax+1);
s = [1:n]';
x = x0;
r = b - A * x;
ni = 0; % number of iterations
nc = 0; % number of cycles
nb = norm(b);
i0 = index(r);
s = swap(s,1,i0);
bet = r(i0);
resn(1) = norm(r);
rhs(1) = bet;
nresidu = realmax;
iconv = 0;

while nresidu > (epsi * nb) && (ni < nitmax)  % ---- Loop on cycles
 nc = nc + 1;
 LP = zeros(n,m+1); % init basis vectors
 LPs = zeros(n,m+1);
 rot = zeros(2,m); % init Givens rotations
 H = zeros(m+1,m);
 v = r / bet;
 LP(:,1) = v;
 LPs(:,1) = swap(LP(:,1),1,i0);
 for k = 1:m    % start a cycle of CMRH(m)
  ni = ni + 1;  % number of iterations
  w = A * LP(:,k);
  ws = w(s);
  wst = LPs(1:k,1:k) \ ws(1:k);
  H(1:k,k) = wst;
  ws(1:k) = 0;
  ws(k+1:n) = ws(k+1:n) - sum(LPs(k+1:n,1:k) * wst,2);
  sp = invperm(s);
  w = ws(sp);
  if k+1 < n
   sj = s(k+1:n);
   i1 = index(w(sj));
   i0 = i1 + k;
   s = swap(s,k+1,i0);
   maxw = w(sj(i1));
  else
   maxw = w(n);
  end % if k+1
  H(k+1,k) = maxw;
  LP(:,k+1) = w / maxw;
  LPs(:,k+1) = ws / maxw;
  LPs = swapLP(LPs,k+1,i0);
  nw1 = maxw;
  % apply the preceding Givens rotations to the last column
  for kk = 1:k-1
   h1 = H(kk,k);
   h2 = H(kk+1,k);
   H(kk+1,k) = -rot(2,kk) * h1 + rot(1,kk) * h2;
   H(kk,k) = rot(1,kk) * h1 + conj(rot(2,kk)) * h2;
  end  % for kk
  % compute, store and apply a new rotation to zero
  % the last term in kth column
  nw = H(k,k);
  [cc,ss] = K_givens(nw,nw1);
  % store the rotation for the next columns
  rot(1,k) = cc; % cosine
  rot(2,k) = ss; % sine
  % modify the diagonal entry and the right-hand side
  H(k,k) = rot(1,k) * nw + conj(rot(2,k)) * nw1;
  c = rhs(k);
  rhs(k) = rot(1,k) * c;
  rhs(k+1) = -rot(2,k) * c;
  nresidu = abs(rhs(k+1));  %  estimate of the residual norm
  resn(ni+1) = nresidu;
  % convergence test or too many iterations
  if nresidu < (epsi * nb) || ni >= nitmax
   iconv = 1;
   break  % get out of the k loop
  end  % if nresidu
 end  %  for k
 % computation of the solution at the end of the cycle
 y = triu(H(1:k,1:k)) \ rhs(1:k);
 x = x0 + LP(:,1:k) * y;
 if iconv == 1
  % we have to stop
  resn = resn(1:ni+1);
  return
 end % if iconv
 % we have not converged yet, compute the residual and restart
 r = b - A * x;
 x0 = x;
 s = [1:n]';
 i0 = index(r);
 s = swap(s,1,i0);
 bet = r(i0);
 nresidu = norm(r);
 rhs = zeros(m+1,1);
 rhs(1) = bet;
end % while, loop on cycles
resn = resn(1:ni+1);
end % function

function s = swap(s,i,j);
% s = s; % no pivoting
% return
ss = s(i);
s(i) = s(j);
s(j) = ss;
end % function

function L = swapLP(L,i,j);
ss = L(i,:);
L(i,:) = L(j,:);
L(j,:) = ss;
end % function

function i0 = index(u);
[y,I] = max(abs(u));
i0 = I(1);
% i0 = 1; % no pivoting
end % function

function ip=invperm(perm);
% inverse permutation of perm
n = length(perm);
in = [1:n];
ip = perm;
ip(perm) = in;
end % function




