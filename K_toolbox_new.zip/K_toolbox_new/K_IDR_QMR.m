function [x,ni,resn,matvec] = K_IDR_QMR(A,b,x0,epsi,nitmax,s);
%K_IDR_QMR QMR IDR with s vectors from Van Gizjen, Sleijpen and Zemke

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

nb = norm(b);
nA = size(A,1);
x = x0;
r = b - A * x;
matv = 1;
matvec = zeros(1,nitmax+1);
matvec(1) = matv;
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
rng('default');
P = randn(nA,s); % random shadow vectors
P = orth(P); % orthogonalization
mu = 0;
Pt = P';
G = zeros(nA,s);
W = zeros(nA,s+1);
M = zeros(s,s);
cs = zeros(s+2,1);
sn = zeros(s+2,1);
phih = resn(1);
g = r / phih;
nn = 0;
j = 0;
rho = phih;
ni = 0;

for k = 1:nitmax
 ni = ni + 1; % number of iterations
 for kk = 1:s+1
  nn = nn + 1;
  u = zeros(s+2,1);
  u(s+1) = 1;
  m = Pt * g;
  if nn > s
   gamma = M \ m;
   v = g - G * gamma;
   u(1:s) = -gamma;
  else
   v = g;
  end % if nn
  M(:,1:s-1) = M(:,2:s);
  M(:,s) = m;
  G(:,1:s-1) = G(:,2:s);
  G(:,s) = g;
  g = A * v;  % matrix vector product
  matv = matv + 1;
  if kk == s+1
   j = j + 1;
   mu = compmu(A,g,v);
  end % if kk
  g = g - mu * v;
  h = mu * u;
  if kk < s+1
   beta = G(:,s-kk+1:s)' * g;
   g = g - G(:,s-kk+1:s) * beta;
   betah = G(:,s-kk+1:s)' * g;
   g = g - G(:,s-kk+1:s) * betah;
   beta = beta + betah;
   h(s+1-kk+1:s+1) = h(s+1-kk+1:s+1) + beta;
  end % if kk
  h(s+2) = norm(g);
  g = g / h(s+2);
  rr = zeros(s+3,1);
  rr(2:s+3) = h;
  lb = max(1,s+3-nn);
  for l = lb:s+1
   t = rr(l);
   rr(l) = cs(l) * t + sn(l) * rr(l+1);
   rr(l+1) = -conj(sn(l)) * t + cs(l) * rr(l+1);
  end % for l
  [cc,ss,rrs2] = rotg(rr(s+2),rr(s+3));
  cs(s+2) = cc;
  sn(s+2) = ss;
  rr(s+2) = rrs2;
  phi = cs(s+2) * phih;
  phih = -conj(sn(s+2)) * phih;
  cs(1:s+1) = cs(2:s+2);
  sn(1:s+1) = sn(2:s+2);
  w = (v - W * rr(1:s+1)) / rr(s+2);
  W(:,1:s) = W(:,2:s+1);
  W(:,s+1) = w;
  x = x + phi * w;
  rho = abs(phih) * sqrt(j+1);
 end % for kk
 matvec(ni+1) = matv;
 nresidu = rho;
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end % for k
resn = resn(1:ni+1);
matvec = matvec(1:ni+1);
end % function

function mu = compmu(A,t,v);
kappa = 0.7;
om = (t' * v) / (t' * t);
rho = (t' * v) / (norm(t) * norm(v));
if abs(rho) < kappa
 om = (om * kappa) / abs(rho);
end
if abs(om) > eps
 mu = 1 / om;
else
 mu = sqrt(norm(A,1) * norm(A,inf));
end 
end % function

function [cs,sn,r]= rotg(a,b);
if abs(a) < eps
 cs = 0;
 sn = 1;
 r = b;
else
 t = abs(a) + abs(b);
 rho = t * sqrt((a / t)^2 + (b / t)^2);
 alp = a / abs(a);
 cs = abs(a) / rho;
 sn = alp * conj(b) / rho;
 r = alp * rho;
end % if abs
end % function
















