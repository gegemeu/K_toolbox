function [x,ni,resn,resnbi,matvec] = K_QMRBiCGStab(A,b,x0,epsi,nitmax);
%K_QMRBICGSTAB Quasi Minimum Residual Biconjugate gradient squared stabilized

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = upper bound of the residual norms
% resnbi = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

nA = size(A,1);
nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
resnbi = zeros(1,nitmax+1);
matvec = zeros(1,nitmax+1);
resn(1) = norm(r);
resnbi(1) = resn(1);
matv = 1;
matvec(1) = matv;
p = zeros(nA,1);
v = zeros(nA,1);
d = zeros(nA,1);
r0 = r; % shadow vector
rho = 1;
alp = 1;
om = 1;
tau = resn(1);
tet = 0;
eta = 0;
ni = 0;

for k =  1:nitmax
 ni = ni + 1; % number of iterations
 rho_old = rho;
 rho = transpose(r0) * r;
 bet = (rho * alp) / (rho_old * om);
 p = r + bet * (p - om * v);
 v = A * p;  % matrix vector product
 matv = matv + 1;
 alp = rho / (transpose(r0) * v);
 s = r - alp * v;
 tett = norm(s) / tau;
 c = 1 / sqrt(1 + tett^2);
 taut = tau * tett * c;
 etat = c^2 * alp;
 dt = p + ((tet^2 * eta) / alp) * d;
 xt = x + etat * dt;
 t = A * s;  % matrix vector product
 matv = matv + 1;
 om = (transpose(s) * t) / (transpose(t) * t);
 r = s - om * t;
 nresidu = norm(r);
 resnbi(ni+1) = nresidu;
 tet = nresidu / taut;
 c = 1 / sqrt(1 + tet^2);
 tau = taut * tet * c;
 eta = c^2 * om;
 d = s +((tett^2 * etat) / om) * dt;
 x = xt + eta * d;
 nresidu = sqrt(ni+1) * abs(tau);
 resn(ni+1) = nresidu;
 matvec(ni+1) = matv;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end % for k
resn = resn(1:ni+1);
resnbi = resnbi(1:ni+1);
matvec = matvec(1:ni+1);






