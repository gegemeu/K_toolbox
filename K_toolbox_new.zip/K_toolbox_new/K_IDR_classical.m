function [x,ni,resn] = K_IDR_classical(A,b,x0,epsi,nitmax);
%K_IDR_CLASSICAL Classical IDR with one vector, IDR(1)

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

nb = norm(b);
nA = size(A,1);
x = x0;
r = A * x - b;
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
rng('default');
p = randn(nA,1); % random shadow vector
s = r;
t = A * s;
om = omega(t,s);
dx = -om * s;
dr = -om * t;
x = x + dx;
r = r + dr;
dg = dr;
dy = dx;
gamma = -(p' * r) / (p' * dr);
resn(2) = norm(r);
ni = 2;

for k = 2:nitmax
 ni = ni + 1; % number of iterations
 s = r + gamma * dg;
 t = A * s;  % matrix vector product
 if mod(k,2) == 0
  om = omega(t,s);
 end % if
 dx = gamma * dy - om * s;
 dr = gamma * dg - om * t;
 x = x + dx;
 r = r + dr;
 if mod(k,2) == 1
  dg = dr;
  dy = dx;
 end % if
 gamma = -(p' * r) / (p' * dg);
 nresidu = norm(r);
 resn(ni) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end % for k
resn = resn(1:ni);
end % function

function om = omega(t,s)
angle = 0.7;
ns = norm(s);
nt = norm(t);
ts = t' * s;
rho = abs(ts / (nt * ns));
om = ts / (nt * nt);
if rho < angle 
 om = om * angle / rho;
end % if
end % function

