function [x,ni,resn,err] = K_GMRES_MGS_err_est(A,b,x0,epsi,nitmax,delay);
%K_GMRES_MGS_ERR_EST Full GMRES with modified Gram-Schmidt and error norm estimates

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% delay = we estimate delay iterations back
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% err = error norm estimates

n = size(A,1);
rhs = zeros(nitmax+1,1);
V = zeros(n,nitmax+1);
H = zeros(nitmax+1,nitmax);
HH = zeros(nitmax+1,nitmax);
rot = zeros(2, nitmax);  % init Givens rotations
resn = zeros(1,nitmax+1);
err = zeros(1,nitmax+1);
x = x0;
r = b - A * x;
nr = r' * r;
ni = 0;
nb = norm(b);
bet = norm(r);
resn(1) = bet;
rhs(1) = bet;
v = r / bet;
V(:,1) = v;

for k = 1:nitmax
 ni = ni + 1;  % number of iterations
 w = A * v;    % matrix vector product
 for j = 1:k   % modified Gram-Schmidt
  vj = V(:,j);
  vw = vj' * w;
  H(j,k) = vw;
  w = w - vw * vj;
 end  % for j
 nw = norm(w);
 v = w / nw;
 H(k+1,k) = nw;
 HH(1:k+1,k) = H(1:k+1,k); % save the new column of H
 V(:,k+1) = v;  % next basis vector
 nw1 = nw;
 % apply the preceding Givens rotations to the last column
 for kk = 1:k-1
  h1 = H(kk,k);
  h2 = H(kk+1,k);
  H(kk+1,k) = -rot(2,kk) * h1 + rot(1,kk) * h2;
  H(kk,k) = rot(1,kk) * h1 + conj(rot(2,kk)) * h2;
 end  % for kk
 % compute, store and apply a new rotation to zero
 % the last term in kth column
 nw = H(k,k);
 [cc,ss] = K_givens(nw,nw1);
 % store the rotation for the next columns
 rot(1,k) = cc; % cosine
 rot(2,k) = ss; % sine
 % modify the diagonal entry and the right-hand side
 H(k,k) = rot(1,k) * nw + conj(rot(2,k)) * nw1;
 c = rhs(k);
 rhs(k) = rot(1,k) * c;
 rhs(k+1) = -rot(2,k) * c;
 nresidu = abs(rhs(k+1));  %  estimate of the residual norm
 resn(ni+1) = nresidu;
 % convergence test or too many iterations
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 if k > delay
  dd = delay;
  % partitioning of HH
  Hk = HH(1:k-dd,1:k-dd);
  Wk = HH(1:k-dd,k-dd+1:k);
  Hkt = HH(k-dd+1:k,k-dd+1:k);
  hkp = HH(k-dd+1,k-dd);
  e1t = zeros(dd,1);
  e1t(1) = 1;
  [Qkt,Rkt] = qr(full(Hkt));
  hkt1 = Rkt \ (Qkt' * e1t);
  wk = Wk * hkt1;
  [Qk,Rk] = qr(full(Hk));
  hkwk1 = Rk \ (Qk' * wk);
  e1 = zeros(k-dd,1);
  e1(1) = 1;
  hk1 = Rk \ (Qk' * e1);
  ekhk1 = hk1(k-dd);
  ekhkw = hkwk1(k-dd);
  gammak = hkp * ekhk1 / (1 - hkp * ekhkw);
  sk1 = ekhk1 + gammak * ekhkw;
  % ekk = estimate of the FOM error
  ekk = (hkp * sk1)^2 * (hkt1'*hkt1) + gammak^2 * (hkwk1' * hkwk1);
  el = zeros(k-dd,1);
  el(k-dd) = 1;
  yy = Qk * ( Rk' \ el);
  % vector tk = inv(H_k' H_k) e_k
  tk = Rk \ (Qk' * yy);
  tkk = tk(k-dd);
  dkp = hkp^2 / (1 + hkp^2 * tkk);
  uk = dkp * tk;
  % additional term for GMRES
  add = 2 * gammak * ekhk1 * (hkwk1' * uk) + ekhk1^2 * norm(uk)^2;
%   if ni > delay+1
%    est_old = err(ni-dd-1);
%    est = sqrt(nr * (ekk + add));
%   end % if ni
  if ekk + add > 0 
   err(ni-dd) = sqrt(nr * (ekk + add));
  else
   err(ni-dd) = 0;
  end % if ekk
 end % if k
end  %  for k
% computation of the solution
y = triu(H(1:k,1:k)) \ rhs(1:k);
x = x0 + V(:,1:k) * y;
resn = resn(1:ni+1);
err = err(1:ni+1);




