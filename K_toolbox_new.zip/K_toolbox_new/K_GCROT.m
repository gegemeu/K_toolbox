function [x,ni,resn,matvec] = K_GCROT(A,b,x0,epsi,nitmax,m,kt);
%K_GCROT, truncated version of Hicken and Zingg

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% m = number of GMRES inner iterations
% we keep kt vectors
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

n = size(A,1);
nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
matvec = zeros(1,nitmax+1);
matv = 1;
H = zeros(m+1,m);
HH = H;
C = zeros(n,kt);
U = zeros(n,kt);
V = zeros(n,m+1);
rot = zeros(2,m);
resn(1) = norm(r);
ni = 0;

for kk = 1:nitmax
 ni = ni + 1;  % number of outer iterations
 B = zeros(kk,nitmax);
 bet = norm(r);
 v = r / bet;
 V(:,1) = v;
 rhs = zeros(m+1,1);
 rhs(1) = bet;
 for k = 1:m % m GMRES inner iterations
  Av = A * V(:,k); % matrix vector product
  matv = matv + 1;
  w = Av;
  if kk > 1
   for l = 1:min(kk-1,kt) % orthogonalize against C_k
    gl = C(:,l)' * w;
    B(l,k) = gl;
    w = w - gl * C(:,l);
   end % for l
  end % if k > 1
  % construction of the basis vectors (modified Gram-Schmidt)
  % and entries of H (into the last column of H)
  for l = 1:k
   gl = V(:,l)' * w;
   H(l,k) = gl;
   w = w - gl * V(:,l);
  end % for l
  dk = w;
  gk = norm(dk);
  dk1 = dk / gk;
  H(k+1,k) = gk;
  V(:,k+1) = dk1; % next basis vector
  gk1 = gk;
  HH(1:k+1,k) = H(1:k+1,k);
  % apply the preceding Givens rotations to the last column just computed
  for kkk = 1:k-1
   g1 = H(kkk,k);
   g2 = H(kkk+1,k);
   H(kkk+1,k) = -rot(2,kkk) * g1 + rot(1,kkk) * g2;
   H(kkk,k) = rot(1,kkk) * g1 + conj(rot(2,kkk)) * g2;
  end % for kkk
  % compute, store and apply a new rotation to zero the last term in kth column
  gk = H(k,k);
  cs = sqrt(abs(gk1)^2 + abs(gk)^2);
  if abs(gk) < abs(gk1)
   mu = gk / gk1;
   tau = conj(mu) / abs(mu);
  else
   mu = gk1 / gk;
   tau = mu / abs(mu);
  end % if
  % store the rotation for the next columns
  rot(1,k) = abs(gk) / cs; % cosine
  rot(2,k) = abs(gk1) * tau / cs; % sine
  % modify the diagonal entry and the right-hand side
  H(k,k) = rot(1,k) * gk + conj(rot(2,k)) * gk1;
  c = rhs(k);
  rhs(k) = rot(1,k) * c;
  rhs(k+1) = -rot(2,k) * c;
 end %  for k - end of GMRES cycle
 y = triu(H(1:m,1:m)) \ rhs(1:m);
 if kk == 1
  u = V(:,1:m) * y;
 else
  km = min(kk-1,kt);
  u = V(:,1:m) * y - U(:,1:km) * B(1:km,1:m) * y;
 end % if kk
 c = V(:,1:m+1) * HH(1:m+1,1:m) * y;
 nc = norm(c);
 if nc > 0
  c = c / nc;
  u = u / nc;
  cr = c' * r;
  r = r - cr * c;
  x = x + cr * u;
  if kk <= kt
   C(:,kk) = c;
   U(:,kk) = u;
  else
   %remove the first vector
   C(:,1:kt-1) = C(:,2:kt);
   U(:,1:kt-1) = U(:,2:kt);
   C(:,kt) = c;
   U(:,kt) = u;
  end
 end % if nc
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 matvec(ni+1) = matv;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end  % for kk
resn = resn(1:ni+1);
matvec = matvec(1:ni+1);






