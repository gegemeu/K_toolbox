function [x,ni,resn] = K_BiCG(A,b,x0,epsi,nitmax);
%K_BICG Biconjugate gradient

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

% The shadow vector is taken as the initial residual

nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
rt = r;
p = r;
pt = rt;
At = transpose(A);
rrt = transpose(rt) * r;
ni = 0;

for k =  1:nitmax
 ni = ni + 1; % number of iterations
 Ap = A * p; % matrix vector product
 Atp = At * pt; % matrix vector product with the transpose
 gamma = rrt / (transpose(pt) * Ap);
 x = x + gamma * p;
 r = r - gamma * Ap;
 rt = rt - gamma * Atp;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 rrtn = transpose(rt) * r;
 mu = rrtn / rrt;
 rrt = rrtn;
 p = r + mu * p;
 pt = rt + mu * pt;
end % for k


