function [c,s,rot] = K_givens(x,y);
%K_GIVENS zeroes the second component of [x; y]

% c and s, cosine and sine of the rotation
% rot is the 2x2 rotation matrix

if y == 0
 c = 1;
 s = 0;
elseif x == 0
 c = 0;
 s = 1;
else
 cs = sqrt(abs(y)^2 + abs(x)^2);
 if abs(x) < abs(y)
  mu = x / y;
  tau = conj(mu) / abs(mu);
 else
  mu = y / x;
  tau = mu / abs(mu);
 end % if abs
 c = abs(x) / cs; % cosine
 s = abs(y) * tau / cs; % sine
end % if y
%
% Sending back rot is optional
if nargout == 3
 rot = [c conj(s); -s c];
else
 rot = [];
end



