function [x,ni,resn,matvec] = K_TFQMR(A,b,x0,epsi,nitmax);
%K_TFQMR Transpose free QMR of Roland Freund

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

nA = size(A,1);
nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
matvec = zeros(1,nitmax+1);
resn(1) = norm(r);
matv = 2;
matvec(1) = matv;
y1 = r;
y2 = zeros(nA,1);
d = zeros(nA,1);
w = r;
r0 = r' * r;
theta = 0;
eta = 0;
rho = r0;
tau = sqrt(r0);
v = A * r;
u1 = v;
ni = 0;

for k =  1:nitmax
 ni = ni + 1; % number of iterations
 sigma = r' * v;
 alpha = rho / sigma;
 for j = 1:2
  if j == 2
   y2 = y1 - alpha * v;
   u2 = A * y2;  % matrix vector product
   matv = matv + 1;
  end % if j == 2
  m = 2 * ni - 2 + j;
  if j == 1
   w = w - alpha * u1;
   d = y1 + (theta * theta * eta / alpha) * d;
  else
   w = w - alpha * u2;
   d = y2 + (theta * theta * eta / alpha) * d;
  end % if j == 1
  theta = norm(w) / tau;
  c = 1 / sqrt(1 + theta * theta);
  tau = tau * theta * c;
  eta = c * c * alpha;
  x = x + eta * d;
 end % for j
 nresidu = tau * sqrt(m + 1);
 resn(ni+1) = nresidu;
 matvec(ni+1) = matv;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 rhon = r' * w;
 beta = rhon / rho;
 rho = rhon;
 y1 = w + beta * y2;
 u1 = A * y1;  % matrix vector product
 matv = matv + 1;
 v = u1 + beta * (u2 + beta * v);
end %  for k
resn = resn(1:ni+1);
matvec = matvec(1:ni+1);



