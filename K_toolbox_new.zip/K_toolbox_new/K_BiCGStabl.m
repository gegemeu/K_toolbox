function [x,ni,resn,matvec] = K_BiCGStabl(A,b,x0,epsi,nitmax,ell,kappa);
%K_BICGSTABL Biconjugate gradient squared stabilized (ell)

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% ell = number of vectors in the local basis (2 by default)
% kappa = parameter for the computation of omega (0.7 by default)
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

% Adapted from the code in IFISS by D. Silvester and al.

if nargin < 6
 l = 2; % BiCGStab(2)
else
 l = ell;
end % if
if nargin < 7
 kappa = 0.7;
end % if
nb = norm(b);
nA = size(A,1);
x = x0;
r = b - A * x;
matvec = zeros(1,nitmax+1);
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
matv = 1;
matvec(1) = matv;
rt = r; % shadow vector
u = zeros(nA,1);
gamma = 1;
omega = 1;
nr = 1;
ni = 0;

for k =  1:nitmax
 ni = ni + 1; % number of iterations
 % BiCG part
 gamma = -omega * gamma;
 y = r;
 for j = 1:l
  rho = rt' * y;
  beta = rho / gamma;
  u = r - beta * u;
  y = A * u(:,j);  % matrix vector product
  matv = matv + 1;
  u(:,j+1) = y;
  gamma = rt' * y;
  alpha = rho / gamma;
  x = x + alpha * u(:,1);
  r = r - alpha * u(:,2:j+1);
  y = A * r(:,j);  % matrix vector product
  r(:,j+1) = y;
  matv = matv + 1;
  resn(nr+1) = norm(r(:,end));
  matvec(nr+1) = matv;
  nr = nr + 1;
 end % for j
 % MR part
 G = r' * r;
 Gamma0 = [1; -G(2:l,2:l) \ G(2:l,1); 0];
 Gamma1 = [0; -G(2:l,2:l) \ G(2:l,l+1); 1];
 NGamma0 = Gamma0' * G * Gamma0;
 NGamma1 = Gamma1' * G * Gamma1;
 omega = Gamma0' * G * Gamma1;
 cosine = abs(omega) / sqrt(NGamma0 * NGamma1);
 omega = omega / NGamma1;
 if cosine < kappa
  omega = (kappa / cosine) * omega;
 end % if
 Gamma = Gamma0 - omega * Gamma1;
 x = x - r * [Gamma(2:l+1); 0];
 r = r * Gamma;
 u = u * Gamma;
 nresidu = norm(r(:,end));
 resn(nr+1) = nresidu;
 matvec(nr+1) = matv;
 nr = nr + 1;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end % for k
matvec = matvec(1:nr);
resn = resn(1:nr);





