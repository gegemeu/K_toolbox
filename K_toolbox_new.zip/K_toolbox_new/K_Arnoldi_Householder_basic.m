function [V,H] = K_Arnoldi_Householder_basic(A,u,nitmax);
%K_ARNOLDI_HOUSEHOLDER_BASIC Arnoldi with Householder transformations

% Straightforward coding, K_Arnoldi_Householder is more efficient

% u = starting vector
% nitmax iterations
% V = basis vectors, H = upper Hessenberg matrix

n = size(A,1);
V = zeros(n,nitmax);
H = zeros(nitmax,nitmax);
mi = norm(u);
u = u / mi;
w = zeros(n,1);
w(1) = 1;
sir = sign(u(1));
if sir == 0
 sir = 1;
end % if
if mi ~= 0
 beta = u(1) + sir * mi;
 w(2:n) = u(2:n) ./ beta;
end % if
P = (eye(n) - (2 * (w * w')) / (w' * w));
V(:,1) = P(:,1);

for j = 1:nitmax
 Av = A * V(:,j); % matrix vector product
 rr = P' * Av;
 if j < n
  mn = norm(rr(j+1:n));
 else
  mn = 0;
 end % if j
 if mn ~= 0
  if j+1 <= n
   w(1:j) = zeros(j,1);
   w(j+1:n) = rr(j+1:n);
   mi = norm(w);
   if mi ~=0 && j+1 < n
    beta = w(j+1) + sign(w(j+1)) * mi;
    if abs(beta) <= eps
     beta = w(j+1) - sign(w(j+1)) * mi;
    end % if abs
    if abs(beta) <= eps
     beta = 1;
    end % if abs
    w(j+2:n) = w(j+2:n) ./ beta;
   end % if mi
   w(j+1) = 1;
   PP = (eye(n) - (2 * (w * w')) / (w' * w));
   rr = PP * rr;
  end % if j+1
 else % if mn
  w = zeros(n,1);
 end % if mn
 if j <= n-1
  H(1:j+1,j) = rr(1:j+1);
 else
  H(1:n,n) = rr(1:n);
 end % if j
 if norm(w) ~= 0
  P = P * PP;
 end % if norm
 if j < n
  V(:,j+1) = P(:,j+1);
 end % if j
end % for j

