function [x,ni,resn] = K_QORopt_tridiag(A,b,x0,epsi,nitmax);
%K_QOROPT_TRIDIAG Q-OR Opt, uses V^T V = tridiagonal matrix

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

n = size(A,1);
V = zeros(n,nitmax+1);
H = zeros(nitmax+1,nitmax);
nu = zeros(nitmax+1,1);
alpk = zeros(nitmax,1);
betk = zeros(nitmax,1);
rhs = zeros(nitmax+1,1);
rot = zeros(2, nitmax); 
resn = zeros(1,nitmax+1);
x = x0;
r = b - A * x;
nb = norm(b);
bet = norm(r);
resn(1) = bet;
resnt(1) = bet;
rhs(1) = bet;
v = r / bet;
V(:,1) = v;
nu(1) = 1;
ni = 0;
% End of initialization

for k = 1:nitmax
 ni = ni + 1; % number of iterations
 Av = A * v; % matrix vector product
 if k == 1
  vAv = v' * Av; % first iteration
  vAAv = Av' * Av;  
  if abs(vAv) <= 1e-14 % breakdown?
   fprintf('\n K QORopt_tridiag: Initialization breakdown, v^T A v = %g \n',vAv)
   H(1,1) = 0;
  else
   H(1,1) = vAAv / vAv;
  end % if abs(vAv)
  vt = Av - H(1,1) * V(:,1);
  H(2,1) = norm(vt);
  v = vt / H(2,1); % new basis vector
  V(:,2) = v;
  Vk = V(:,1:2);
  nu(2) = - nu(1) * H(1,1) / H(2,1);
  nu2 = nu(2)^2;
  alpk(1) = nu2 / (nu2 - 1);
  alpk(2) = alpk(1);
  betk(1) = - nu(2) / (nu2 - 1);
 else % k ~= 1
  vktA = (Av' * Vk)'; % this is to avoid the transposition of Vk
  % product with a tridiagonal matrix
  s = alpk(1:k) .* vktA;
  s(1:k-1) = s(1:k-1) + betk(1:k-1) .* vktA(2:k);
  s(2:k) = s(2:k) + betk(1:k-1) .* vktA(1:k-1);
  AVks = Av - Vk * s;
  alp = norm(AVks)^2;
  % new column of H
  if abs(vktA(k)) <= 0 % breakdown?
   fprintf('\n K QORopt_tridiag: Breakdown iteration %d, value = %g, k = %d \n',ni,vktA(k),k)
   return
  else
   beta = alp / vktA(k);
   H(1:k,k) = s;
   H(k,k) = H(k,k) + beta;
  end % if abs
  vt = AVks - beta * v;
  h = norm(vt);
  % the inverse of abs(nu) gives the norm of the residual
  nu(k+1) = (nu(k) * h) / (v' * vt);
  nuk1 = nu(k-1)^2;
  nuk = nu(k)^2;
  nukp = nu(k+1)^2;
  % entries of the tridiagonal matrix (inverse of V^T V)
  alpk(k) = nuk1 / (nuk - nuk1) + nukp / (nukp - nuk);
  betk(k) = -(nu(k) * nu(k+1)) / (nukp - nuk);
  alpk(k+1) = nukp / (nukp - nuk);
  H(k+1,k) = h;
  if k < n
   v = vt / h; % next basis vector
   V(:,k+1) = v;
   Vk = [Vk v];
  end % if k < n
 end % if k == 1
 % apply the preceding Givens rotations to the last column
 for kk = 1:k-1
  h1 = H(kk,k);
  h2 = H(kk+1,k);
  H(kk+1,k) = -rot(2,kk) * h1 + rot(1,kk) * h2;
  H(kk,k) = rot(1,kk) * h1 + conj(rot(2,kk)) * h2;
 end % for kk
 % compute, store and apply a new rotation 
 nw = H(k,k);
 nw1 = H(k+1,k);
 [cc,ss] = K_givens(nw,nw1);
 rot(1,k) = cc; % cosine
 rot(2,k) = ss; % sine
 nresidu = H(k+1,k) * abs(rhs(k) / H(k,k)); %  estimate of the residual norm
 resn(ni+1) = nresidu;
 y = triu(H(1:k,1:k)) \ rhs(1:k);
 x = x0 + V(:,1:k) * y;
 % convergence test or too many iterations
 if nresidu < (epsi * nb) || ni >= nitmax
  break % get out of the k loop
 end % if nresidu
 if k < nitmax
  H(k,k) = rot(1,k) * nw + conj(rot(2,k)) * nw1;
  c = rhs(k);
  rhs(k) = rot(1,k) * c;
  rhs(k+1) = -rot(2,k) * c;
 end % if k
end %  for k
% computation of the solution
y = triu(H(1:k,1:k)) \ rhs(1:k);
x = x0 + V(:,1:k) * y;
resn = resn(1:ni+1);

