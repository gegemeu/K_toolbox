function [V,W,T,Tt] = K_biortho_bis(A,v,w,nitmax);
%K_BIORTHO_BIS Biorthogonal basis with 3-term recurrence

% Basis vectors normalized such that w' * v = 1
% This works only for real data

% A = matrix
% v, w = starting vectors
% nitmax iterations
% V, W = basis vectors
% T, Tt = tridiagonal matrices

wv = w' * v;
rho = sqrt(abs(wv));
r0 = rho;
zeta = sign(wv) * rho;
v = v / rho;
w = w / zeta;
n = size(A,1);
v1 = zeros(n,1);
w1 = v1;
T = zeros(nitmax,nitmax);
Tt = zeros(nitmax,nitmax);
V = zeros(n,nitmax);
W = zeros(n,nitmax);
R = zeros(n,nitmax);
At = A';
beta = 0;
delta = 0;
tau = 1;

for k = 1:nitmax 
 V(:,k) = v;
 W(:,k) = w;
 Av = A * v;
 Aw = At * w;
 alpha = w' * Av;
 p = Av - alpha * v - beta * v1;
 s = Aw - alpha * w - delta * w1;
 wv = p' * s;
 rho = sqrt(abs(wv));
 zeta = sign(wv) * rho;
 v1 = v;
 w1 = w;
 v = p / rho;
 w = s / zeta;
% check the breakdown
 if abs(wv) < 1e-13 
  fprintf('\n K biortho bis: Near breakdown step %d, wv new = %12.5e \n',k,wv)
 end
 beta = zeta;
 delta = rho;
 T(k,k) = alpha;
 T(k,k+1) = beta;
 T(k+1,k) = rho;
 Tt(k,k) = alpha;
 Tt(k,k+1) = delta;
 Tt(k+1,k) = zeta;
 tau = -tau * rho / alpha;
 R(:,k) = r0 * tau * v;
end % for k
T = T(1:nitmax,1:nitmax);
Tt = Tt(1:nitmax,1:nitmax);

