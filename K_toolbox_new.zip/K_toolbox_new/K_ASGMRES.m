function [x,ni,resn] = K_ASGMRES(A,b,x0,epsi,nitmax,nu);
%K_ASGMRES Adaptive Simpler GMRES

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% nu = parameter for choosing between SGMRES and RB-GMRES (in [0,1])
%          nu = 0 -> SGMRES, nu = 1 -> RB-GMRES 
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

% works only for real data

n = size(A,1);
V = zeros(n,nitmax+1);
Q = zeros(n,nitmax);
betq = zeros(nitmax,1);
T = zeros(nitmax,nitmax);
rhs = zeros(nitmax,1);
nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
nrq = norm(r);
resn(1) = nrq;
V(:,1) = r / nrq;
Av = A * V(:,1);
[q,betaq] = household(Av,2);
Q(:,1) = q;
betq(1) = betaq;
qa = q' * Av;
T(1,1) = Av(1) - betaq * qa * q(1); % apply the Householder reflection
qk = -betaq * q(1) * q;
qk(1) = 1 + qk(1);
rhs(1) = r' * qk;
r = r - rhs(1) * qk;
nrold = nrq;
nrq = norm(r);
resn(2) = nrq;
if nrq <= nu * nrold
  V(:,2) = r / nrq;
else
  V(:,2) = qk; % new basis vector
end % if nrq
ni = 1;

for k = 2:nitmax
 ni = ni + 1; % number of iterations
 Av = A * V(:,k); % matrix vector product
 t = apply_house(Q,betq,1,k-1,Av); % apply the preceding reflections to the column of A V
 [Q,betq] = qr_add_col(Q,k-1,betq,t); % add the new column, add to V and bet
 T(1:k-1,k) = t(1:k-1);
 qa = Q(:,k)' * t; % apply the last reflection for the diagonal entry
 T(k,k) = t(k) - betq(k) * qa * Q(k,k);
 % we need the k-th column of k
 ek = zeros(n,1); ek(k) = 1;
 qk = apply_house_rev(Q,betq,1,k,ek); % apply the Householder reflections in reverse order
 rhs(k) = r' * qk;
 r = r - rhs(k) * qk;
 nrold = nrq;
 nrq = norm(r);
 if nrq <= nu * nrold
  V(:,k+1) = r / nrq;
 else
  V(:,k+1) = qk; % new basis vector
 end % if nrq
 nresidu = nrq;
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break % get out of the k loop
 end % if nresidu
end % for k
t = T(1:k,1:k) \ rhs(1:k);
x = x0 + V(:,1:k) * t;
resn = resn(1:ni+1);
end % function

function [v,beta,P] = household(x,m);
nx = length(x);
x = x(m-1:nx);
n = length(x);
sig = x(2:n)' * x(2:n);
v = [1; x(2:n)];
if sig == 0
 beta = 0;
else
 mu = sqrt(x(1)^2 + sig);
 if x(1) <= 0
  v(1) = x(1) - mu;
 else
  v(1) = -sig/(x(1) + mu);
 end % if x
 beta = 2 * v(1)^2 / (sig + v(1)^2);
 v = v / v(1);
end % if sig
v = [zeros(m-2,1); v];
if nargout == 3
 P = speye(nx,nx) - beta * (v * v');
end % if nargout
end % function

function y = apply_house(V,bet,ns,ne,x);
for k = ns:ne
 vk = V(:,k);
 x = x - bet(k) * (vk' * x) * vk;
end % for k
y = x;
end % function

function [V,bet] = qr_add_col(V,nv,bet,u);
[n,m] = size(V);
bet = bet(:);
if nv+2 > n
 return
end % if
[v,beta] = household(u,nv+2); % we must zero the components of u from nv+2 to n
V(:,nv+1) = v;
bet(nv+1) = beta;
end % function

function y = apply_house_rev(V,bet,ns,ne,x);
for k = ne:-1:ns
 vk = V(:,k);
 x = x - bet(k) * (vk' * x) * vk;
end % for k
y = x;
end % function


