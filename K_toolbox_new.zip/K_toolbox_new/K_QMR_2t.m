function [x,ni,resn] = K_QMR_2t(A,b,x0,w0,epsi,nitmax);
%K_QMR_2T QMR 2-term recurrences without look-ahead

% A, b = matrix and right-hand side
% x0 = starting vector
% w0 = shadow vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

n = size(A,1);
resn = zeros(1,nitmax);
v = b;
nb = norm(b);
rho = norm(v);
v = v / rho;
if norm(w0) == 0
 w0 = b;
end % if
if ~isempty(w0)
 w = w0 / norm(w0);
else
 w = v;
end % if
p = zeros(n,1);
q = p;
d = p;
s = q;
At = transpose(A);
r = b - A * x0;
x = x0;
resn(1) = norm(r);
c1 = 1;
eps = 1;
zeta = 1;
theta = 0;
eta = -1;
ni = 0;

for k = 1:nitmax
 ni = ni + 1;
 delta = transpose(w) * v;
 p = v - ((zeta * delta) / eps) * p;
 q = w - ((rho * delta) / eps) * q;
 Ap = A * p;   % matrix vector product
 Atq = At * q; % matrix vector product with the transpose
 eps = transpose(q) * Ap;
 beta = eps / delta;
 v = Ap - beta * v;
 w = Atq - beta * w;
 rho1 = rho;
 rho = norm(v);
 zeta = norm(w);
 theta1 = theta;
 theta = rho / (c1 * abs(beta));
 c = 1 / sqrt(1 + theta^2);
 eta = -eta * (rho1 * c^2) / (beta * c1^2);
 c1 = c;
 d = eta * p + (theta1 * c)^2 * d;
 s = eta * Ap + (theta1 * c)^2 * s;
 v = v / rho;
 w = w / zeta;
 x = x + d;
 r = r - s;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end % for k
resn = resn(1:ni+1);







