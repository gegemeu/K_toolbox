function [x,ni,nc,resn] = K_FOMm_MGS(A,b,x0,m,epsi,nitmax);
%K_FOMM_MGS Restarted FOM with modified Gram-Schmidt

% A, b = matrix and right-hand side
% x0 = starting vector
% m = restart parameter
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% nc = number of cycles
% resn = residual norms (may be different from || b - A x_k ||)

if m < 1
 error(' K FOMm MGS: The restart parameter m has to be positive')
end % if
m = min(m,nitmax);
n = size(A,1);
rhs = zeros(m+1,1);
resn = zeros(1,nitmax+1);
x = x0;
r = b - A * x;
ni = 0; % number of iterations
nc = 0; % number of cycles
nb = norm(b);
bet = norm(r);
resn(1) = bet;
rhs(1) = bet;
nresidu = realmax;
iconv = 0;

while nresidu > (epsi * nb) && (ni < nitmax) % ---- Loop on cycles
 nc = nc + 1;
 V = zeros(n,m+1); % init basis vectors
 rot = zeros(2,m); % init Givens rotations
 H = zeros(m+1,m);
 v = r / bet;
 V(:,1) = v;
 for k = 1:m    % start a cycle of GMRES(m)
  ni = ni + 1;  % number of iterations
  w = A * v;    % matrix vector product
  for j = 1:k  % modified Gram-Schmidt
   vj = V(:,j);
   vw = vj' * w;
   H(j,k) = vw;
   w = w - vw * vj;
  end  % for j
  nw = norm(w);
  v = w / nw;
  H(k+1,k) = nw;
  V(:,k+1) = v;  % next basis vector
  nw1 = nw;
  % apply the preceding Givens rotations to the last column
  for kk = 1:k-1
   h1 = H(kk,k);
   h2 = H(kk+1,k);
   H(kk+1,k) = -rot(2,kk) * h1 + rot(1,kk) * h2;
   H(kk,k) = rot(1,kk) * h1 + conj(rot(2,kk)) * h2;
  end  % for kk
  nresidu = H(k+1,k) * abs(rhs(k) / H(k,k));  %  estimate of the residual norm
  resn(ni+1) = nresidu;
  % convergence test or too many iterations
  if nresidu < (epsi * nb) || ni >= nitmax
   iconv = 1;
   break  % get out of the k loop
  end  % if nresidu
  if k < m
   nw = H(k,k);
   [cc,ss] = K_givens(nw,nw1);
   % store the rotation for the next columns
   rot(1,k) = cc; % cosine
   rot(2,k) = ss; % sine
   % modify the diagonal entry and the right-hand side
   H(k,k) = rot(1,k) * nw + conj(rot(2,k)) * nw1;
   c = rhs(k);
   rhs(k) = rot(1,k) * c;
   rhs(k+1) = -rot(2,k) * c;
  end % if k
 end  %  for k, end of one cycle
 % computation of the solution at the end of the cycle
 y = triu(H(1:k,1:k)) \ rhs(1:k);
 x = x0 + V(:,1:k) * y;
 if iconv == 1
  % we have to stop
  resn = resn(1:ni+1);
  return
 end % if iconv
 % we have not converged yet, compute the residual and restart
 r = b - A * x;
 x0 = x;
 bet = norm(r);
 nresidu = bet;
 H = zeros(m+1,m);
 rhs = zeros(m+1,1);
 rhs(1) = bet;
end % while, loop on cycles
resn = resn(1:ni+1);


