function [V,H] = K_QORopt_basic(A,u,nitmax);
%K_QOROPT_BASIC Q-OR opt basis

% Straightforward coding

% A = matrix
% u = starting vector
% nitmax iterations
% V = basis vectors
% H = upper Hessenberg matrix

% Initialization phase
n = size(A,1);
V = zeros(n,nitmax);
H = zeros(nitmax,nitmax);
nu = zeros(nitmax,1);
V(:,1) = u / norm(u);
Av = A * V(:,1);
omega = V(:,1)' * Av;
alpha = Av' * Av - omega ^2;
H(1,1) = omega + alpha / omega;
vt = Av - H(1,1) *  V(:,1);
H(2,1) = norm(vt);
V(:,2) = vt / H(2,1);
Av = A * V(:,2);
nu(1) = 1;
nu(2) = -H(1,1) / H(2,1);
% End of initialization

for j = 2:nitmax
 t = (V(:,1:j)' * V(:,1:j)) \ nu(1:j);
 vtA = V(:,1:j)' * Av;
 s = (V(:,1:j)' * V(:,1:j)) \ vtA;
 omega = vtA' * t;
 alpha = Av' * Av - vtA' * s;
 H(1:j,j) = s + (alpha / omega) * t;
 if j < n
  vt = Av - V(:,1:j) * H(1:j,j);
  H(j+1,j) = norm(vt);
  nu(j+1) = - (nu(1:j)' * H(1:j,j)) / H(j+1,j);
  V(:,j+1) = vt / H(j+1,j);  % next basis vector
  Av = A * V(:,j+1);
 end % if j
end  % for j


