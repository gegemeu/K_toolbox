function [x,ni,resn,matvec] = K_CSBiCGStab(A,b,x0,epsi,nitmax);
%K_CSBICGSTAB Composite Step Biconjugate gradient squared stabilized

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

% this does not work as well as BiCGStab in case of 1x1 pivots
% the normalization is different from BiCGStab

nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
matvec = zeros(1,nitmax+1);
resn(1) = norm(r);
matv = 1;
matvec(1) = matv;
p = r;
r0 = r;
r0t = r0;
q = A * r;
e = q;
rho = transpose(r0t) * r;
phi = resn(1);
mu = 1;
ni = 0;

for k =  1:nitmax
 ni = ni + 1; % number of iterations
 sig = (transpose(r0t) * q) * mu;
 c = A * q;  % matrix vector product
 matv = matv + 1;
 u = sig * r - rho * q;
 y = A * u;  % matrix vector product
 d = A * y;  % matrix vector product
 matv = matv + 2;
 om = (transpose(y) * u) / (transpose(y) * y);
 rh = u - om * y;
 eh = y - om * d;
 psi = norm(rh);
 if psi < abs(sig) * phi
  one_step = 1;
 else
  a11 = transpose(r0t) * q;
  a12 = transpose(r0t) * y;
  a21 = transpose(r0t) * c;
  a22 = transpose(r0t) * d;
  del = a11 * a22 - a21 * a12;
  b1 = rho / mu;
  b2 = transpose(r0t) * eh; % error in the paper
  alp = a22 * b1 - a12 * b2;
  alp1 = -a21 * b1 + a11 * b2;
  s2 = del * r - alp * q - alp1 * y;
  t2 = del * e - alp * c - alp1 * d;
  omt = (transpose(t2) * s2) / (transpose(t2) * t2);
  nut2 = norm(s2 - omt * t2);
  if abs(del) * psi < abs(sig) * nut2
   one_step = 1;
  else
   v2 = A * t2;  % matrix vector product
   w2 = A * v2;  % matrix vector product
   matv = matv + 2;
   z2 = t2 - om * v2;
   u2 = s2 - om * t2;
   om2 = (transpose(z2) * u2) / (transpose(z2) * z2);
   gam1 = -(om + om2);
   gam2 = om * om2;
   rh2 = s2 + gam1 * t2 + gam2 * v2;
   nu2 = norm(rh2);
   eh2 = t2 + gam1 * v2 + gam2 * w2;
   if abs(del) * psi < abs(sig) * nu2
    one_step = 1;
   else
    one_step = 0;
   end % if abs 2
  end % if abs 1
 end % if psi
 %  one_step = 1;
 if one_step
  r = rh / sig;
  e = eh / sig;
  phi = psi / sig;
  x = x + (rho * p + om * u) / sig;
  mu = (mu * rho) / (sig * om);
  rho_old = rho;
  rho = mu * (transpose(r0t) * r);
  bet = rho / rho_old;
  p = r + bet * (p - om * q);
  q = e + bet * (q - om * c); % q = A p
 else
  r = rh2 / del;
  e = eh2 / del;
  phi = nu2 / del;
  x = x + (alp * p + alp1 * u - gam1 * s2 - gam2 * t2) / del;
  mu = -mu * (alp1 * rho) / (del * gam2);
  rho = (transpose(r0t) * r) * mu;
  b1 = transpose(r0t) * t2;
  b2 = transpose(r0t) * v2;
  bet = (a22 * b1 - a12 * b2) / del;
  bet1 = (-a21 * b1 + a11 * b2) / del;
  p = r - bet * (p + gam1 * q + gam2 * c) - bet1 * (u + gam1 * y + gam2 * d);
  q = A * p;  % matrix vector product
  matv = matv + 1;
 end % if one_step
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 matvec(ni+1) = matv;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end % for k
resn = resn(1:ni+1);
matvec = matvec(1:ni+1);



