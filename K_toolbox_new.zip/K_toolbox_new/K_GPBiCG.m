function [x,ni,resn,matvec] = K_GPBiCG(A,b,x0,epsi,nitmax);
%K_GPBICG GPBi-CG of S.L. Zhang

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

nA = size(A,1);
nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
matvec = zeros(1,nitmax+1);
resn(1) = norm(r);
matv = 1;
matvec(1) = matv;
r0 = r; % shadow vector
t = zeros(nA,1);
w = zeros(nA,1);
u = zeros(nA,1);
p = zeros(nA,1);
z = zeros(nA,1);
bet = 0;
r0r = transpose(r0) * r;
ni = 0;

for k = 1:nitmax
 ni = ni + 1; % number of iterations
 p = r + bet * (p - u);
 Ap = A * p;  % matrix vector product
 matv = matv + 1;
 alp = r0r / (transpose(r0) * Ap);
 y = t - r - alp * w + alp * Ap;
 t_old = t;
 t = r - alp * Ap;
 At = A * t;  % matrix vector product
 matv = matv + 1;
 yy = transpose(y) * y;
 yt = transpose(y) * t;
 yAt = transpose(y) * At;
 Att = transpose(At) * t;
 AtAt = transpose(At) * At;
 if k > 1
  yAtAty = AtAt * yy - yAt * yAt;
  zeta = (yy * Att - yt * yAt) / yAtAty;
  eta = (AtAt * yt - yAt * Att) / yAtAty;
 else
  zeta = Att / AtAt;
  eta = 0;
 end % if k
 u = zeta * Ap + eta * (t_old - r + bet * u);
 z = zeta * r + eta * z - alp * u;
 x = x + alp * p + z;
 r = t - eta * y - zeta * At;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 matvec(ni+1) = matv;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 r0r_old = r0r;
 r0r = transpose(r0) * r;
 bet = (alp / zeta) * (r0r / r0r_old);
 w = At + bet * Ap;
end % for k
resn = resn(1:ni+1);
matvec = matvec(1:ni+1);









