function [x,ni,resn] = K_BiCGStab(A,b,x0,epsi,nitmax);
%K_BICGSTAB Biconjugate gradient squared stabilized

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
p = r;
r0 = r;
Ap = A * p;
rkrt = r0' * r;
ni = 0;

for k =  1:nitmax
 ni = ni + 1; % number of iterations
 gamma = rkrt / (r0' * Ap);
 s = r - gamma * Ap;
 As = A * s;  % matrix vector product
 om = (As' * s) / (As' * As);
%  om = omega(As,s); % same as in IDR
 x = x + gamma * p + om * s;
 r = s - om * As;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 rkr = r0' * r;
 mu = (rkr / rkrt) * (gamma / om);
 rkrt = rkr;
 p = r + mu * (p - om * Ap);
 Ap = A * p;  % matrix vector product
end % for k
resn = resn(1:ni+1);
end % function

function om = omega(t,s)
angle = 0.7;
ns = norm(s);
nt = norm(t);
ts = t'*s;
rho = abs(ts/(nt*ns));
om=ts/(nt*nt);
if ( rho < angle )
 om = om*angle/rho;
end % if
end % function


