function [x,ni,resn] = K_GCR(A,b,x0,epsi,nitmax);
%K_CGR Generalized conjugate residual

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

% works only for real data

n = size(A,1);
nb = norm(b);
x = x0;
r = b - A * x;
P = zeros(n,nitmax+1);
AP = zeros(n,nitmax+1);
resn = zeros(1,nitmax+1);
pAAp = zeros(nitmax+1,1);
p = r;
Ap = A * p;
P(:,1) = p;
AP(:,1) = Ap;
pAAp(1) = Ap' * Ap;
resn(1) = norm(r);
ni = 0;

for k = 1:nitmax
 ni = ni + 1;  % number of iterations
 alpha = (r' * Ap) / pAAp(k);
 r = r - alpha * Ap;
 x = x + alpha * p;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 Ar = A * r; % matrix vector product
 beta = -(Ar' * AP(:,1:k))' ./ pAAp(1:k);
 p = r + P(:,1:k) * beta;
 Ap = Ar + AP(:,1:k) * beta;
 P(:,k+1) = p;
 AP(:,k+1) = Ap;
 pAAp(k+1) = Ap' * Ap;
end  % for k
resn = resn(1:ni+1);


