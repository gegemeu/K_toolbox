function [x,ni,resn] = K_GMRES_MGS_A(A,b,x0,epsi,nitmax);
%K_GMRES_MGS Full GMRES with modified Gram-Schmidt, Ayachour's version

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

n = size(A,1);
V = zeros(n,nitmax+1);
H = zeros(nitmax+1,nitmax);
u = zeros(nitmax,1);  
resn = zeros(1,nitmax+1);
x = x0;
r = b - A * x;
ni = 0;
nb = norm(b);
bet = norm(r);
resn(1) = bet;
v = r / bet;
V(:,1) = v;
alpha = 1;

for k = 1:nitmax
 ni = ni + 1;  % number of iterations
 w = A * v;    % matrix vector product
 for j = 1:k   % modified Gram-Schmidt
  vj = V(:,j);
  vw = vj' * w;
  H(j,k) = vw;
  w = w - vw * vj;
 end  % for j
 nw = norm(w);
 v = w / nw;
 H(k+1,k) = nw;
 V(:,k+1) = v;  % next basis vector
 if k > 1
  s = H(2:k,k)' * u(1:k-1);
 else 
  s = 0;
 end % if k
 ukk = conj(H(1,k)) - s;
 gamma = 1 / sqrt(H(k+1,k)^2 + (abs(ukk) * alpha)^2);
 sk = H(k+1,k) * gamma;
 alpha_old = alpha;
 alpha = alpha * sk;
 u(k) = ukk / H(k+1,k); % H(K+1,k) ~= 0?
 nresidu = bet * alpha;  %  estimate of the residual norm
 resn(ni+1) = nresidu;
 rhs = (bet / (1 + norm(u(1:k))^2)) * u(1:k);
 y = H(2:k+1,1:k) \ rhs;
 x = x0 + V(:,1:k) * y;
 % convergence test or too many iterations
 if nresidu < (epsi * nb) || ni >= nitmax || abs((alpha_old - alpha) / alpha) < 1e-10
  % the test on alpha may stop the iteration to early for convergence!
  break  % get out of the k loop
 end  % if nresidu
end  %  for k
% computation of the solution
% rhs = [sk^2 * u(1:k-1); gamma^2 * u(k)];
rhs = (bet / (1 + norm(u(1:k))^2)) * u(1:k);
y = H(2:k+1,1:k) \ rhs;
x = x0 + V(:,1:k) * y;
resn = resn(1:ni+1);

