function [V,H,L,R] = K_QORopt_basis_trunc(A,b,nitmax,pp,qq);
%K_QOROPT_BASIS_TRUNC Truncated Q-OR optimal basis

% A, b = matrix and starting vector
% nitmax iterations
% pp, qq = numbers of vectors in AV and V

% Initialization phase
n = size(A,1);
V = zeros(n,nitmax+1);
R = eye(nitmax+1,nitmax+1);
L = zeros(nitmax+1,nitmax+1);
AV = zeros(n,nitmax);
nuu = zeros(1,nitmax+1);
nuu(1) = 1;
ni = 0;
bet = norm(b);
v = b / bet;
V(:,1) = v;
% End of initialization

for k = 2:nitmax
 ni = ni + 1;
 Av = A * v; % matrix-vector product
 AV(:,k-1) = Av; % store the matrix-vector products
 kp = max(1,k-pp); % starting index in AV
 lp = min(pp,k-1); % number of vectors in AV
 kq = max(1,k-qq); % starting index in V
 lq = min(qq,k-1); % number of vectors in V
 while lp + lq > k  % we do not need more than k vectors
  if lq > 1
   kq = kq + 1;
   lq = lq - 1;
  elseif lp > 1
   kp = kp + 1;
   lp = lp - 1;
  else
   error(' K QORopt_basis_trunc: We cannot reduce the number of vectors any longer')
  end % if
 end % while
 if k == 2
  vAv = v' * Av;
  alpha = Av' * Av - vAv^2;
  omega = vAv;
  if abs(vAv) <= 1-14 % breakdown?
   fprintf('\n K QORopt_basis_trunc: Initialization breakdown, v^T A v = %g \n',vAv)
   return
  else
   z = vAv + alpha / omega;
   v = Av - z * v;
   L(1,1) = z;
  end % if abs
 else % if k == 2
  Ck = [AV(:,kp:k-2) V(:,kq:k-1)];
  sk = size(Ck,2);
  rsk = max(sk-lq,0);
  nut = [zeros(rsk,1); nuu(k-lq:k-1)'];
  CCk = Ck' * Ck; % matrix-matrix product
  CAv = Ck' * Av; % matrix-vector product
  yy = CCk \ CAv; % linear solve
  alpha = Av' * Av - CAv' * yy;
  yyy = CCk \ nut; % linear solve
  omega = Av' * Ck * yyy;
  if abs(omega) <= 1e-14 % breakdown?
   fprintf('\n K QORopt_basis_trunc: Breakdown iteration %d, value = %g\n',ni,omega)
   return
  end % if abs
  z = yy + (alpha / omega) * yyy;
  v = Av - Ck * z; % next basis vector
  L(1:k-1,k-1) = [zeros(k-1-lq,1); z(sk-lq+1:end)];
  R(k-2-lp+2:k-2,k-1) = -z(1:lp-1);
 end % if k = 2
 nk = norm(v);
 v = v / nk;
 V(:,k) = v;
 % subdiagonal entry
 L(k,k-1) = nk;
 nuu(k) = -(nuu(1:k-1) * L(1:k-1,k-1)) / L(k,k-1);
end %  for k
L = L(1:ni,1:ni);
R = R(1:ni,1:ni);
H = L / R;




