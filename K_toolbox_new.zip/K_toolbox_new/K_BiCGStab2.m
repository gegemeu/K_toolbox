function [x,ni,resn] = K_BiCGStab2(A,b,x0,epsi,nitmax);
%K_BICGSTAB2 Biconjugate gradient squared stabilized 2

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

% In this code we combine the odd and even steps into one iteration

nb = norm(b);
nA = size(A,1);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
r0 = r;
u = zeros(nA,1);
alp = 1;
om2 = 1;
rho0 = 1;
ni = 0;

for k =  1:nitmax
 ni = ni + 1; % number of iterations
 % even BiCG step
 rho0 = -om2 * rho0;
 rho1 = transpose(r0) * r;
 beta = alp * rho1 / rho0;
 rho0 = rho1;
 u = r - beta * u;
 v = A * u;  % matrix vector product
 gamma = transpose(r0) * v;
 alp = rho0 / gamma;
 r = r - alp * v;
 x = x + alp * u;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 s = A * r;  % matrix vector product
 % odd BiCG step
 rho1 = transpose(r0) * s;
 beta = alp * rho1 / rho0;
 rho0 = rho1;
 v = s - beta * v;
 w = A * v;  % matrix vector product
 gamma = transpose(r0) * w;
 alp = rho0 / gamma;
 u = r - beta * u;
 r = r - alp * v;
 s = s - alp * w;
 t = A * s;  % matrix vector product
 % GCR(2) step
 om1 = transpose(r) * s;
 mu = transpose(s) * s;
 nuu = transpose(s) * t;
 tau = transpose(t) * t;
 om2 = transpose(r) * t;
 tau = tau - (nuu^2) / mu;
 om2 = (om2 - nuu * om1 / mu) /tau;
 om1 = (om1 - nuu * om2) / mu;
 x = x + om1 * r + om2 * s + alp * u;
 r = r - om1 * s - om2 * t;
 u = u - om1 * v - om2 * w;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
end % for k
resn = resn(1:ni+1);



