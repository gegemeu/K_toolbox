function [x,ni,nc,resn] = K_QORm_optinv(A,b,x0,m,epsi,nitmax);
%K_QORM_OPTINV Restarted Q-OR optimal

% A, b = matrix and right-hand side
% x0 = starting vector
% m = restart parameter
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% nc = number of cycles
% resn = residual norms (may be different from || b - A x_k ||)

if m < 1
 error(' K QORm optinv: The restart parameter m has to be positive')
end % if
m = min(m,nitmax);
n = size(A,1);
rhs = zeros(m+1,1);
resn = zeros(1,nitmax+1);
x = x0;
r = b - A * x;
ni = 0; % number of iterations
nc = 0; % number of cycles
nb = norm(b);
bet = norm(r);
resn(1) = bet;
rhs(1) = bet;
nresidu = realmax;
iconv = 0;

while nresidu > (epsi * nb) && (ni < nitmax) % ---- Loop on cycles
 nc = nc + 1;
 V = zeros(n,m+1); % init basis vectors
 rot = zeros(2,m); % init Givens rotations
 H = zeros(m+1,m);
 Lt = zeros(m+1,m+1);
 for k = 1:m    % start a cycle of Q-OR optinv(m)
  ni = ni + 1;  % number of iterations
  if k == 1
   V(:,1) = r / bet;
   Vko = V(:,1);
   Av = A * V(:,1); % matrix vector product
   Lt(1,1) = 1;
   omega = V(:,1)' * Av;
   alpha = Av' * Av - omega^2;
   H(1,1) = omega + alpha / omega;
   vt = Av - H(1,1) *  V(:,1);
   nw = norm(vt);
   H(2,1) = nw;
   V(:,2) = vt / H(2,1);
  else % if k
   Av = A * V(:,k); % matrix vector product
   vV = V(:,1:k-1)' * V(:,k);
   vtA = (Av' * V(:,1:k))';
   if abs(vtA(k)) <= 0 % breakdown?
    fprintf('\n K Q-ORm optinv: breakdown iteration %d, vtA(k) = %12.5e \n',ni,vtA(k))
    error(' stop')
   end
   if abs(vtA(k)) <= 1e-14 % near-breadown?
    fprintf('\n K Q-ORm optinv: small vtA(k) iteration %d \n',ni)
   end
   lt = Lt(1:k-1,1:k-1) * vV;
   yt = lt' * Lt(1:k-1,1:k-1);
   lkt = lt' * lt;
   if lkt >=1
    pknu = Vko * yt';
    lkk = norm(V(:,k) - pknu);
   else
    lkk = sqrt(1 - lkt);
   end % if lkt
   Lt(k,1:k) = [-yt / lkk, 1 / lkk];
   lA = Lt(1:k,1:k) * vtA;
   s = Lt(1:k,1:k)' * lA;
   alpha = Av' * Av - lA' * lA;
   beta = alpha / vtA(k);
   H(1:k-1,k) = s(1:k-1);
   H(k,k) = s(k) + beta;
   if k <= n
    vt = Av - V(:,1:k) * H(1:k,k);
    nw = norm(vt);
    H(k+1,k) = nw;
    V(:,k+1) = vt / H(k+1,k); % next basis vector
    Vko = V(:,1:k);
   end % if k
  end % if k == 1
  nw1 = nw;
  % apply the preceding Givens rotations to the last column
  for kk = 1:k-1
   h1 = H(kk,k);
   h2 = H(kk+1,k);
   H(kk+1,k) = -rot(2,kk) * h1 + rot(1,kk) * h2;
   H(kk,k) = rot(1,kk) * h1 + conj(rot(2,kk)) * h2;
  end  % for kk
  % compute, store and apply a new rotation to zero
  % the last term in kth column
  nw = H(k,k);
  [cc,ss] = K_givens(nw,nw1);
  % store the rotation for the next columns
  rot(1,k) = cc; % cosine
  rot(2,k) = ss; % sine
  %  estimate of the residual norm
  nresidu = H(k+1,k) * abs(rhs(k) / H(k,k));
  resn(ni+1) = nresidu;
  % convergence test or too many iterations
  if nresidu < (epsi * nb) || ni >= nitmax
   iconv = 1;
   break % get out of the k loop
  end % if nresidu
  if k < m
   % modify the diagonal entry and the right-hand side
   H(k,k) = rot(1,k) * nw + conj(rot(2,k)) * nw1;
   c = rhs(k);
   rhs(k) = rot(1,k) * c;
   rhs(k+1) = -rot(2,k) * c;
  end % if k
 end  %  for k, end of one cycle
 % computation of the solution at the end of the cycle
 y = triu(H(1:k,1:k)) \ rhs(1:k);
 x = x0 + V(:,1:k) * y;
 if iconv == 1
  % we have to stop
  resn = resn(1:ni+1);
  return
 end % if iconv
 % we have not converged yet, compute the residual and restart
 r = b - A * x;
 x0 = x;
 bet = norm(r);
 nresidu = bet;
 rhs = zeros(m+1,1);
 rhs(1) = bet;
end % while, loop on cycles
resn = resn(1:ni+1);


