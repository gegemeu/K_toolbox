function [x,ni,resn] = K_FOM_MGS(A,b,x0,epsi,nitmax);
%K_FOM_MGS Full FOM with modified Gram-Schmidt

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

n = size(A,1);
rhs = zeros(nitmax+1,1);
V = zeros(n,nitmax+1);
H = zeros(nitmax+1,nitmax);
rot = zeros(2, nitmax);  % init Givens rotations
resn = zeros(1,nitmax);
x = x0;
r = b - A * x;
ni = 0;
nb = norm(b);
bet = norm(r);
resn(1) = bet;
rhs(1) = bet;
v = r / bet;
V(:,1) = v;

for k = 1:nitmax
 ni = ni + 1;  % number of iterations
 w = A * v;    % matrix vector product
 for j = 1:k   % modified Gram-Schmidt
  vj = V(:,j);
  vw = vj' * w;
  H(j,k) = vw;
  w = w - vw * vj;
 end  % for j
 nw = norm(w);
 v = w / nw;
 H(k+1,k) = nw;
 V(:,k+1) = v;  % next basis vector
 nw1 = nw;
 % apply the preceding Givens rotations to the last column
 for kk = 1:k-1
  h1 = H(kk,k);
  h2 = H(kk+1,k);
  H(kk+1,k) = -rot(2,kk) * h1 + rot(1,kk) * h2;
  H(kk,k) = rot(1,kk) * h1 + conj(rot(2,kk)) * h2;
 end  % for kk
 % compute, store and apply a new rotation to zero
 % the last term in kth column
 nw = H(k,k);
 [cc,ss] = K_givens(nw,nw1);
 % store the rotation for the next columns
 rot(1,k) = cc; % cosine
 rot(2,k) = ss; % sine
 nresidu = H(k+1,k) * abs(rhs(k) / H(k,k));  %  estimate of the residual norm
 resn(ni+1) = nresidu;
 % convergence test or too many iterations
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 % modify the diagonal entry and the right-hand side
 if k < nitmax
  H(k,k) = rot(1,k) * nw + conj(rot(2,k)) * nw1;
  c = rhs(k);
  rhs(k) = rot(1,k) * c;
  rhs(k+1) = -rot(2,k) * c;
 end % if k
end  %  for k
% computation of the solution
y = triu(H(1:k,1:k)) \ rhs(1:k);
x = x0 + V(:,1:k) * y;
resn = resn(1:ni+1);

