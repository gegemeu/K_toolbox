function [V,W,T,Tt] = K_biortho(A,v,w,nitmax);
%K_BIORTHO Biorthogonal basis with 3-term recurrence

% Basis vectors of unit norm
% This works only for real data

% A = matrix
% v, w = starting vectors
% nitmax iterations
% V, W = basis vectors
% T, Tt = tridiagonal matrices

v = v / norm(v);
w = w / norm(w);
n = size(A,1);
v1 = zeros(n,1);
w1 = v1;
T = zeros(nitmax,nitmax); % could also be declared as a sparse matrix
Tt = zeros(nitmax,nitmax); % could also be declared as a sparse matrix
V = zeros(n,nitmax);
W = zeros(n,nitmax);
At = A';
beta = 0;
rho = 1;
zeta = 1;
delta = beta * rho  / zeta;
wv = w' * v;

for k = 1:nitmax 
 V(:,k) = v;
 W(:,k) = w;
 Av = A * v;
 Aw = At * w;
 alpha = (w' * Av) / wv;
 p = Av - alpha * v - beta * v1;
 s = Aw - alpha * w - delta * w1;
 rho = norm(p);
 zeta = norm(s);
 v1 = v;
 w1 = w;
 v = p / rho;
 w = s / zeta;
 wv_new = w' * v;
% check the breakdown
 if abs(wv_new) < 1e-13 
  fprintf('\n K biortho: Near breakdown step %d, wv new = %12.5e \n',k,wv_new)
 end % if
 beta = zeta * wv_new / wv;
 delta = beta * rho  / zeta;
 wv = wv_new;
 T(k,k) = alpha;
 T(k,k+1) = beta;
 T(k+1,k) = rho;
 Tt(k,k) = alpha;
 Tt(k,k+1) = delta;
 Tt(k+1,k) = zeta;
end % for k
T = T(1:nitmax,1:nitmax);
Tt = Tt(1:nitmax,1:nitmax);

