function [V,H] = K_QORopt(A,u,nitmax);
%K_QOROPT Q-OR opt basis

% Coding using the inverses of the Cholesky factors

% A = matrix
% u = starting vector
% nitmax iterations
% V = basis vectors, H = upper Hessenberg matrix

% Initialization phase
n = size(A,1);
V = zeros(n,nitmax);
H = zeros(nitmax,nitmax);
Lt = zeros(nitmax,nitmax);
nu = zeros(nitmax,1);
V(:,1) = u / norm(u);
Av = A * V(:,1);
Lt(1,1) = 1;
omega = V(:,1)' * Av;
alpha = Av' * Av;
H(1,1) = alpha / omega;
vt = Av - H(1,1) *  V(:,1);
H(2,1) = norm(vt);
V(:,2) = vt / H(2,1);
nu(1) = 1;
nu(2) = -H(1,1) / H(2,1);
Vjo = V(:,1);
% End of initialization

for j = 2:nitmax
 Av = A * V(:,j);
 vV = V(:,1:j-1)' * V(:,j);
 vtA = (Av' * V(:,1:j))';
 if abs(vtA(j)) <= 0
  fprintf('\n K Q-OR opt: breakdown iteration %d \n',j)
  V = V(:,1:j);
  break
 end
 lt = Lt(1:j-1,1:j-1) * vV;
 yt = lt' * Lt(1:j-1,1:j-1);
 ljt = lt' * lt;
 if ljt >=1
  pjnu = Vjo * yt';
  ljj = norm(V(:,j) - pjnu);
 else
  ljj = sqrt(1 - ljt);
 end % if ljt
 Lt(j,1:j) = [-yt / ljj, 1 / ljj];
 lA = Lt(1:j,1:j) * vtA;
 s = Lt(1:j,1:j)' * lA;
 alpha = Av' * Av - lA' * lA;
 beta = alpha / vtA(j);
 H(1:j-1,j) = s(1:j-1);
 H(j,j) = s(j) + beta;
 if j < n
  vt = Av - V(:,1:j) * H(1:j,j);
  H(j+1,j) = norm(vt);
  nu(j+1) = -(nu(1:j)' * H(1:j,j)) / H(j+1,j);
  V(:,j+1) = vt / H(j+1,j);
  Vjo = V(:,1:j);
 end % if j
end  % for j

