function [x,ni,resn,matvec] = K_IDR(A,b,x0,epsi,nitmax,s);
%K_IDR IDR with s shadow vectors

% First IDR algorithm of Sonneveld and Van Gizjen

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% s = number of shadow vectors
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

nb = norm(b);
nA = size(A,1);
x = x0;
r = b - A * x;
matv = 1;
matvec = zeros(1,nitmax+1);
matvec(1) = matv;
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
rng('default');
P = randn(nA,s); % random shadow vectors
P = orth(P); % orthogonalization
Pt = P';
M = eye(s);
dR = zeros(nA,s);
dX = zeros(nA,s);
for kk = 1:s
 v = r;
 v = A * v;
 matv = matv + 1;
 matvec(kk+1) = matv;
 om = omega(v,r);
 dX(:,kk) = om * r;
 dR(:,kk) = -om * v;
 x = x + dX(:,kk);
 r = r + dR(:,kk);
 resn(kk+1) = norm(r);
 M(:,kk) = Pt * dR(:,kk);
end % for kk
oldest = 1;
m = Pt * r;
nr = s + 1;
ni = 1;

for k = 1:nitmax
 ni = ni + 1; % number of iterations
 for kk = 0:s
  c = M \ m;
  v = r - dR * c;
  % Initialisation new G-space?
  if kk == 0
   t = v;
   t = A * t;  % matrix vector product
   matv = matv + 1;
   matvec(nr+1) = matv;
   om = omega(t,v);
   dR(:,oldest) = -dR * c - om * t;
   dX(:,oldest) = -dX * c + om * v;
  else
   dX(:,oldest) = -dX * c + om * v;
   t = dX(:,oldest);
   t = A * t;  % matrix vector product
   matv = matv + 1;
   matvec(nr+1) = matv;
   dR(:,oldest) = -t;
  end % if kk
  r = r + dR(:,oldest);
  x = x + dX(:,oldest);
  normr = norm(r);
  resn(nr+1) = normr;
  nr = nr + 1;
  dm = Pt * dR(:,oldest);
  m = m + dm;
  M(:,oldest) = dm;
  oldest = oldest + 1;
  if oldest > s
   oldest = 1;
  end
 end % for kk = 0:s
 nresidu = normr;
 if nresidu < (epsi * nb) || nr >= nitmax 
  break  % get out of the k loop
 end  % if nresidu
end % for k
resn = resn(1:nr);
matvec = matvec(1:nr);
end % function

function om = omega(t,s)
% om = (s' * t) / (t' * t); % standard formula
% return
angle = 0.7;
ns = norm(s);
nt = norm(t);
ts = t' * s;
rho = abs(ts / (nt * ns));
om = ts / (nt * nt);
if rho < angle 
 om = om * angle / rho;
end % if
end % function


