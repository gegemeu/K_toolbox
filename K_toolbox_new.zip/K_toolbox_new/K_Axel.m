function [x,ni,resn] = K_Axel(A,b,x0,epsi,nitmax);
%K_AXEL Axelsson's method

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

warning off
n = size(A,1);
nb = norm(b);
x = x0;
r = b - A * x;
P = zeros(n,nitmax+1);
AP = zeros(n,nitmax+1);
R = zeros(nitmax,nitmax);
resn = zeros(1,nitmax+1);
p = r;
Ap = A * p;
P(:,1) = p;
AP(:,1) = Ap;
pAAp = Ap' * Ap;
resn(1) = norm(r);
ni = 1;
[Q,bet] = household(Ap,2);
qa = Q(:,1)' * Ap;
R(1,1) = Ap(1) - bet(1) * qa * Q(1,1);
rhs = apply_house(Q,bet,1,1,r);
alpha = R(1,1) \ rhs(1); % least squares problem
r = r - AP(:,1) * alpha;
x = x + P(:,1) * alpha;
resn(2) = norm(r);
Ar = A * r;
beta = -(Ar' * Ap) / pAAp;
p = r + beta * p;
Ap = Ar + beta * Ap;
P(:,2) = p;
AP(:,2) = Ap;
pAAp = Ap' * Ap;

for k = 2:nitmax
 ni = ni + 1;  % number of iterations
 u = apply_house(Q,bet,1,k-1,AP(:,k));
 [Q,bet] = qr_add_col(Q,k-1,bet,u);
 R(1:k-1,k) = u(1:k-1);
 qa = Q(:,k)' * u;
 R(k,k) = u(k) - bet(k) * qa * Q(k,k);
 rhs = apply_house(Q,bet,1,k,r);
 alpha = R(1:k,1:k) \ rhs(1:k); % least squares problem
 r = r - AP(:,1:k) * alpha;
 x = x + P(:,1:k) * alpha;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 Ar = A * r; % matrix vector product
 beta = -(Ar' * Ap) / pAAp;
 p = r + beta * p;
 Ap = Ar + beta * Ap;
 P(:,k+1) = p;
 AP(:,k+1) = Ap;
 pAAp = Ap' * Ap;
end  % for k
resn = resn(1:ni+1);
warning on
end % function

function [v,beta,P] = household(x,m);
nx = length(x);
x = x(m-1:nx);
n = length(x);
sig = x(2:n)' * x(2:n);
v = [1; x(2:n)];
if sig == 0
 beta = 0;
else
 mu = sqrt(x(1)^2 + sig);
 if x(1) <= 0
  v(1) = x(1) - mu;
 else
  v(1) = -sig/(x(1) + mu);
 end % if x
 beta = 2 * v(1)^2 / (sig + v(1)^2);
 v = v / v(1);
end % if sig
v = [zeros(m-2,1); v];
if nargout == 3
 P = speye(nx,nx) - beta * (v * v');
end % if nargout
end % function

function y = apply_house(V,bet,ns,ne,x);
for k = ns:ne
 vk = V(:,k);
 x = x - bet(k) * (vk' * x) * vk;
end % for k
y = x;
end % function

function [V,bet] = qr_add_col(V,nv,bet,u);
[n,m] = size(V);
bet = bet(:);
if nv+2 > n
 return
end % if
[v,beta] = household(u,nv+2); % we must zero the components of u from nv+2 to n
V(:,nv+1) = v;
bet(nv+1) = beta;
end % function




