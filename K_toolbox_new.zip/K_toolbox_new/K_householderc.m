function [v,beta,P] = K_householderc(x,m);
%K_HOUSEHOLDERC Householder transformation

% x can be complex
% It zeroes the components from m to the last
% If m = 2, use K_housec
% The result is x - beta (v' x) v

nx = length(x);
[vv,beta] = K_housec(x(m-1:nx));
v = [zeros(m-2,1); vv];
% Sending back P is optional
if nargout == 3
 P = eye(nx,nx) - beta * (v * v');
end % if nargout


