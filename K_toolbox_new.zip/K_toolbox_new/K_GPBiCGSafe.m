function [x,ni,resn,matvec] = K_GPBiCGSafe(A,b,x0,epsi,nitmax);
%K_GPBICGSAFE GPBi-CGSafe Fujino and al

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

nA = size(A,1);
nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
matvec = zeros(1,nitmax);
resn(1) = norm(r);
matv = 1;
matvec(1) = matv;
r0 = r; % shadow vector
Ap = zeros(nA,1);
Az = zeros(nA,1);
Au = zeros(nA,1);
Ar = A * r;
u = zeros(nA,1);
p = zeros(nA,1);
z = zeros(nA,1);
bet = 0;
r0r = transpose(r0) * r;
ni = 0;

for k = 1:nitmax
 ni = ni + 1; % number of iterations
 p = r + bet * (p - u);
 Ap = Ar + bet * (Ap - Au);
 alp = r0r / (transpose(r0) * Ap);
 a = r;
 bz = Az;
 c = Ar;
 bb = transpose(bz) * bz;
 ca = transpose(c) * a;
 ba = transpose(bz) * a;
 cb = transpose(c) * bz;
 cc = transpose(c) * c;
 if k > 1
  ccbb = cc * bb - cb * cb;
  zeta = (bb * ca - ba * cb) / ccbb;
  eta = (cc * ba - cb * ca) / ccbb;
 else
  zeta = ca / cc;
  eta = 0;
 end % if k
 u = zeta * Ap + eta * (Az + bet * u);
 Au = A * u;  % matrix vector product
 matv = matv + 1;
 t = r - alp * Ap;
 z = zeta * r + eta * z - alp * u;
 Az = zeta * Ar + eta * Az - alp * Au;
 x = x + alp * p + z;
 r = t - Az;
 Ar = A * r;  % matrix vector product
 matv = matv + 1;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 matvec(ni+1) = matv;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 r0r_old = r0r;
 r0r = transpose(r0) * r;
 bet = (alp / zeta) * (r0r / r0r_old);
end % for k
resn = resn(1:ni+1);
matvec = matvec(1:ni+1);









