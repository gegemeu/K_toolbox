function [V,H] = K_QORopt_T(A,u,nitmax);
%K_QOROPT_T Q-OR opt basis

% Coding using the tridiagonal matrices
% Caution: This is less stable than QORopt...

% A = matrix
% u = starting vector
% nitmax iterations
% V = basis vectors, H = upper Hessenberg matrix

% Initialization phase
n = size(A,1);
V = zeros(n,nitmax);
H = zeros(nitmax,nitmax);
nu = zeros(nitmax,1);
% entries of the tridiagonal matrix (inverse of V^T V)
alpk = zeros(nitmax,1);
betk = zeros(nitmax,1);
V(:,1) = u / norm(u);
Av = A * V(:,1);
omega = V(:,1)' * Av;
alpha = Av' * Av;
H(1,1) = alpha / omega;
vt = Av - H(1,1) *  V(:,1);
H(2,1) = norm(vt);
V(:,2) = vt / H(2,1);
nu(1) = 1;
nu(2) = -H(1,1) / H(2,1);
nu2 = nu(2)^2;
alpk(1) = nu2 / (nu2 - 1);
alpk(2) = alpk(1);
betk(1) = - nu(2) / (nu2 - 1);
% End of initialization

for j = 2:nitmax
 Av = A * V(:,j);
 vtA = (Av' * V(:,1:j))';
 if abs(vtA(j)) <= 0
  fprintf('\n K Q-OR opt T: breakdown iteration %d \n',j)
  V = V(:,1:j);
  break
 end % if
 % product with a tridiagonal matrix
 s = alpk(1:j) .* vtA;
 s(1:j-1) = s(1:j-1) + betk(1:j-1) .* vtA(2:j);
 s(2:j) = s(2:j) + betk(1:j-1) .* vtA(1:j-1);
 AVks = Av - V(:,1:j) * s;
 alpha = AVks' * AVks;
 beta = alpha / vtA(j);
 H(1:j-1,j) = s(1:j-1);
 H(j,j) = s(j) + beta;
 if j < n
  vt = AVks - beta * V(:,j);
  H(j+1,j) = norm(vt);
  nu(j+1) = -(nu(1:j)' * H(1:j,j)) / H(j+1,j);
  V(:,j+1) = vt / H(j+1,j);
  nuj1 = nu(j-1)^2;
  nuj = nu(j)^2;
  nujp = nu(j+1)^2;
  alpk(j) = nuj1 / (nuj - nuj1) + nujp / (nujp - nuj);
  betk(j) = -(nu(j) * nu(j+1)) / (nujp - nuj);
  alpk(j+1) = nujp / (nujp - nuj);
 end % if j
end  % for j

