function [V,H] = K_Arnoldi_CGS_2(A,u,nitmax);
%K_ARNOLDI_CG2 Arnoldi with classical Gram-Schmidt and reorthogonalization

% "twice is enough"

% u = starting vector
% nitmax iterations
% V = basis vectors
% H = upper Hessenberg matrix

n = size(A,1);
V = zeros(n,nitmax);
H = zeros(nitmax,nitmax);
u = u / norm(u); 
V(:,1) = u;

for j = 1:nitmax % number of steps
 Av = A * V(:,j); % matrix vector product
 w = Av;
 for i = 1:j
  vAv = V(:,i)' * Av; % classical Gram-Schmidt
  H(i,j) = vAv;
  w = w - vAv * V(:,i);
 end % for i
 ww = w; % reorthogonalization
 for i = 1:j
  alpha = V(:,i)' * ww;
  w = w - alpha * V(:,i);
  H(i,j) = H(i,j) + alpha;
 end % for i
 nw = norm(w);
 if nw == 0
  return
 end
 if j < n
  H(j+1,j) = nw;
  V(:,j+1) = w / nw;  % next basis vector
 end % if j
end % for j

