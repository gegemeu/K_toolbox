function [x,ni,resn,matvec] = K_IDR_Bio(A,b,x0,epsi,nitmax,s);
%K_IDR_BIO Biorthogonal IDR with s vectors

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% s = number of shadow vectors
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

nb = norm(b);
nA = size(A,1);
x = x0;
r = b - A * x;
matv = 1;
matvec = zeros(1,nitmax+1);
matvec(1) = matv;
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
rng('default');
P = randn(nA,s); % rndom shadow vectors
P = orth(P); % orthogonalization
Pt = P';
G = zeros(nA,s);
U = zeros(nA,s);
M = eye(s);
om = 1;
nr = 1;
ni = 0;

for k = 1:nitmax
 ni = ni + 1; % number of iterations
 Ptr = Pt * r;
 for kk = 1:s
  % Solve small system and make v orthogonal to P
  c = M(kk:s,kk:s) \ Ptr(kk:s);
  v = r - G(:,kk:s) * c;
  U(:,kk) = U(:,kk:s) * c + om * v;
  G(:,kk) = A * U(:,kk);  % matrix vector product 
  matv = matv + 1;
  % Bi-Orthogonalize the new basis vectors
  for j = 1:kk-1
   alp = (Pt(j,:) * G(:,kk)) / M(j,j);
   G(:,kk) = G(:,kk) - alp * G(:,j);
   U(:,kk) = U(:,kk) - alp * U(:,j);
  end % for j
  M(kk:s,kk) = Pt(kk:s,:) * G(:,kk);
  % Make r orthogonal to p_j, j = 1,...,kk
  beta = Ptr(kk) / M(kk,kk);
  r = r - beta * G(:,kk);
  x = x + beta * U(:,kk);
  resn(nr+1) = norm(r);
  matvec(nr+1) = matv;
  nr = nr + 1;
  if kk < s
   Ptr(kk+1:s) = Ptr(kk+1:s) - beta * M(kk+1:s,kk);
  end % if
 end % for kk
 v = r;
 t = A * v;  % matrix vector product
 matv = matv + 1;
 om = omega(t,v);
 r = r - om * t;
 x = x + om * v;
 matvec(nr+1) = matv;
 nresidu = norm(r);
 resn(nr+1) = nresidu;
 nr = nr + 1;
 if nresidu < (epsi * nb) || nr >= nitmax 
  break  % get out of the k loop
 end  % if nresidu
end % for k
resn = resn(1:nr-1);
matvec = matvec(1:nr-1);
end % function

function om = omega(t,s)
% om = (s' * t) / (t' * t); % standard formula
% return
angle = 0.7;
ns = norm(s);
nt = norm(t);
ts = t' * s;
rho = abs(ts / (nt * ns));
om = ts / (nt * nt);
if rho < angle 
 om = om * angle / rho;
end % if
end % function


