function [x,ni,resn,matvec] = K_IDRStab(A,b,x0,epsi,nitmax,s,ell);
%K_IDTSTAB IDR(s)Stab(ell) from Sleijpen and Van Gizjen

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% s = number of shadow vectors
% ell = order of the stabilizing polynomial
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)
% matvec = number of matrix vector products

nb = norm(b);
nA = size(A,1);
x = x0;
r = b - A * x;
matv = 1;
matvec = zeros(1,nitmax+1);
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
rng('default');
P = randn(nA,s); % random shadow vectors
P = orth(P); % orthogonalization
Pt = P';
U = zeros(2*nA,s);
v = [r; A * r] / resn(1);
matv = matv + 1;
U(:,1) = v; % use the power basis
for k = 2:s
 v0 = v(nA+1:2*nA);
 v = [v0; A * v0];
 matv = matv + 1;
 mu = U(1:nA,1:k-1)' * v0;
 v = v - U(:,1:k-1) * mu;
 v = v / norm(v(1:nA));
 U(:,k) = v;
end % for k
matvec(1) = matv;
ni = 1;
nr = 1;

for k = 1:nitmax
 ni = ni + 1; % number of iterations (steps)
 for j = 1:ell
  S = Pt * U(j*nA+1:(j+1)*nA,:);
  alp = S \ (Pt * r((j-1)*nA+1:j*nA)); % linear solve
  x = x + U(1:nA,:) * alp;
  r = r - U(nA+1:(j+1)*nA,:) * alp;   % U_1,...,U_j
  r = [r; A * r((j-1)*nA+1:j*nA)];  % matrix vector product
  matv = matv + 1;
  resn(nr+1) = norm(r(1:nA));
  matvec(nr+1) = matv;
  nr = nr + 1;
  v = r; 
  vj = v(j*nA+1:(j+1)*nA);
  beta = S \ (Pt * vj); % linear solve
  v = v - U * beta;
  vj = v(j*nA+1:(j+1)*nA);
  v = [v; A * vj] / norm(vj);  % matrix vector product
  matv = matv + 1;
  V = v;
  for q = 2:s
   v = v(nA+1:end);
   vj = v(j*nA+1:(j+1)*nA);
   beta = S \ (Pt * vj); % linear solve
   v = v - U * beta;
   vj = v(j*nA+1:(j+1)*nA);
   v = [v; A * vj];  % matrix vector product
   matv = matv + 1;
   mu = V(j*nA+1:(j+1)*nA,1:q-1)' * vj;
   v = v - V(:,1:q-1) * mu;
   v = v / norm(v(j*nA+1:(j+1)*nA));
   V(:,q) = v;
  end % for q
  if j < ell
   U = V;
  end % if
 end % for j
 % polynomial step
 R = reshape(r(nA+1:end),[nA,ell]);
 gamma = pinv(R) * r(1:nA);
 x = x + reshape(r(1:end-nA),[nA,ell]) * gamma;
 r = r(1:nA) - R * gamma;
 U0 = V(1:nA,:);
 U1 = V(nA+1:2*nA,:);
 st0 = nA + 1;
 st1 = 2 * nA + 1;
 for j = 1:ell
  U0 = U0 - gamma(j) * V(st0:st0+nA-1,:);
  U1 = U1 - gamma(j) * V(st1:st1+nA-1,:);
  st0 = st0 + nA;
  st1 = st1 + nA;
 end % for j
 U = [U0; U1];
 matvec(nr+1) = matv;
 nresidu = norm(r);
 resn(nr+1) = nresidu;
 nr = nr + 1;
 if nresidu < (epsi * nb) || ni >= nitmax 
  break  % get out of the k loop
 end  % if nresidu
end % for k
matvec = matvec(1:nr);
resn = resn(1:nr);




