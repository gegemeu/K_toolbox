function [x,ni,resn] = K_BiCGS(A,b,x0,epsi,nitmax);
%K_BICGS Biconjugate gradient squared

% A, b = matrix and right-hand side
% x0 = starting vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% resn = residual norms (may be different from || b - A x_k ||)

nb = norm(b);
x = x0;
r = b - A * x;
resn = zeros(1,nitmax+1);
resn(1) = norm(r);
p = r;
u = r;
r0 = r;
Ap = A * p;
rho0 = transpose(r0) * r;
ni = 0;

for k =  1:nitmax
 ni = ni + 1; % number of iterations
 gamma = rho0 / (transpose(Ap) * r0);
 q = u - gamma * Ap;
 qu = q + u;
 x = x + gamma * qu;
 Aqu = A * qu;  % matrix vector product
 r = r - gamma * Aqu;
 nresidu = norm(r);
 resn(ni+1) = nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  break  % get out of the k loop
 end  % if nresidu
 rho = transpose(r) * r0;
 mu = rho / rho0;
 rho0 = rho;
 u = r + mu * q;
 p = u + mu * (q + mu * p);
 Ap = A * p;  % matrix vector product
end % for k
resn = resn(1:ni+1);



