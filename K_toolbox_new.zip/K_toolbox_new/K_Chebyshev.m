function [V,H] = K_Chebyshev(A,u,nitmax,pit);
%K_CHEBYSHEV Chebyshev basis

% A = matrix
% u = starting vector 
% nitmax points
% pit iterations of Arnoldi
% V = basis vectors, H = upper Hessenberg matrix
% if pit < 0, we (loosely) orthogonalize the basis

rng('default');
n = size(A,1);
m = nitmax;
cgs = 0;
if pit < 0
 cgs = 1;
 pit = -pit;
end % if
% pit iterations of Arnoldi
[VV,HH] = K_Arnoldi_MGS(A,u,pit);
HH = HH(1:pit,1:pit);
eigH = eig(full(HH)); % Ritz values
if isreal(eigH)
 cx = (min(eigH) + max(eigH)) / 2;
 cy = 0;
 aa = max(eigH) - min(eigH);
 bb = 0;
 % center of interval
 dd = cx;
 cc = aa / 2;
else
 % get the enclosing ellipse
 [cx,cy,aa,bb,count] = best_ellipse(real(eigH),imag(eigH),1e-3);
 % correction of the center if H is real
 if isreal(HH)
  cy = 0;
 end % if
 cc = sqrt(aa^2 - bb^2);
 % center of ellipse
 dd = cx + 1i * cy;
 if isreal(cc) && cc == 0
  error(' K Chebyshev, the ellipse is a circle')
 end % if
end % if isreal(eigH)
% computation of the coefficients of the Chebyshev recurrence
dc = dd / (cc + 1e-20);
alpC = zeros(m+2,1);
alpC(1) = 1;
alpC(2) = dc;
for j = 3:m+2
 alpC(j) = 2 * dc * alpC(j-1) - alpC(j-2);
end % for j
V = zeros(n,nitmax);
T = zeros(nitmax+1,nitmax);
u = u / norm(u); % u is the starting vector
v = u;
V(:,1) = u;

for j = 1:nitmax % number of steps
 Av = A * V(:,j);
 w = Av;
 % Chebyshev polynomial
 if j == 1
  vv = v - (1 / dd) * w;
  nvv = norm(vv);
  nvv_old = 1;
  V(:,j+1) = vv / nvv;
  T(1,1) = dd;
  T(2,1) = -dd * nvv;
 else
  chi = 1 / (2 * dc - alpC(j) / alpC(j+1));
  xi = 1 / ( 2 * dc * (alpC(j+1) / alpC(j))- 1);
  vv = (2 * dc * chi * V(:,j) - 2 * (chi / cc) * w) * nvv - xi * V(:,j-1) * nvv_old;
  nvv_new = norm(vv);
  V(:,j+1) = vv / nvv_new;
  T(j,j) = dd;
  cchi = cc / (2 * chi);
  T(j-1,j) = -cchi * xi * nvv_old / nvv;
  T(j+1,j) = -cchi * nvv_new / nvv;
  nvv_old = nvv;
  nvv = nvv_new;
 end % if j
end % for j
% Compute H
% loosely orthogonalize the basis?
if cgs == 1
 % use cholQR
 VV = V' * V;
 [R,msg] = chol(VV);
 if msg ~= 0
  % if cholQR fails, use CGS
  [V,R] = orth_cgsR(V(:,1:m+1));
 else
  V = V / R;
 end % if
 H = triu(R) * T(1:m+1,1:m);
else
 H = T(1:m+1,1:m);
end % if cgs
end % function

function [cx,cy,a,b,count] = best_ellipse(x,y,tolerance);
% best enclosing ellipse for a set of 2D points
% using Khachiyan Algorithm
%
% From a code by Nima Moshtagh (nima@seas.upenn.edu)
% University of Pennsylvania

P = [x(:)'; y(:)'];
[d N] = size(P);
Q = zeros(d+1,N);
Q(1:d,:) = P(1:d,1:N);
Q(d+1,:) = ones(1,N);
count = 1;
err = 1;
u = (1/N) * ones(N,1); % first iteration
countmax = 10000;
while err > tolerance
 if count > countmax
  error('best_ellipse: too many iterations')
 end % if
 X = Q * diag(u) * Q';  
 M = diag(Q' * (X \ Q)); 
 [maximum j] = max(M);
 step_size = (maximum - d -1)/((d+1)*(maximum-1));
 new_u = (1 - step_size)*u ;
 new_u(j) = new_u(j) + step_size;
 count = count + 1;
 err = norm(new_u - u);
 u = new_u;
end % while
U = diag(u);
A = (1/d) * inv(P * U * P' - (P * u)*(P*u)' );
% center of the ellipse
c = P * u;
cx = c(1);
cy = c(2);
% semi-axes
[U D V] = svd(A);
dx = abs(max(x) - min(x));
dy = abs(max(y) - min(y));
if dx > dy
 b = 1/sqrt(D(1,1));
 a = 1/sqrt(D(2,2));
else
 a = 1/sqrt(D(1,1));
 b = 1/sqrt(D(2,2));
end % if
end % function

function [V,R] = orth_cgsR(A);
% orthogonalisation of the columns of A
% Classical Gram-Schmidt but returns only R
[m,n] = size(A);
V = zeros(m,n);
R = zeros(n,n);
v = A(:,1);
nv = norm(v);
V(:,1) = v / nv;
R(1,1) = nv;
% orthogonalization (once)
for k = 2:n
 w = A(:,k);
 v = w;
 for j=1:k-1
  alpha = w' * V(:,j);
  R(j,k) = alpha;
  v = v - alpha * V(:,j);
 end % for j
 nv = norm(v);
 R(k,k) = nv;
 if nv <= 1e-15
  fprintf('\n orth_cgsR: Breakdown, step %d \n\n',k)
  return
 end % if
 v = v / norm(v);
 V(:,k) = v;
end % for k
end % function



