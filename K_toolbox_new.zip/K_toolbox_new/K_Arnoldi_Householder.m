function [V,H] = K_Arnoldi_Householder(A,u,nitmax);
%K_ARNOLDI_HOUSEHOLDER Arnoldi with Householder transformations

% More efficient coding than K_Arnoldi_Householder_basic

% u = starting vector
% nitmax iterations
% V = basis vectors
% H = upper Hessenberg matrix

n = size(A,1);
m = min(n,nitmax);
V = zeros(n,m);  % basis vectors
W = zeros(n,m);  % Householder vectors
ww = zeros(1,m); % Householder vector norms
H = zeros(m,m);
mi = norm(u);
u = u / mi;
w = eye(n,1);
w(1) = 1;
sir = sign(u(1));
if sir == 0
 sir = 1;
end
if mi  ~= 0
 beta = u(1) + sir * mi;
 w(2:n) = u(2:n) ./ beta;
end % if mi
W(:,1) = w;
wtw = w' * w;
ww(1) = wtw;
e1 = eye(n,1);
vv = e1 - 2 * (w(1) / wtw) * w;
V(:,1) = vv;

for j = 1:m
 Av = A * V(:,j);  % matrix-vector product
 rAv = Av;
 for jj = 1:j
  wx = W(:,jj);
  wtAv = wx' * rAv;
  rAv = rAv - 2 * (wtAv / ww(jj)) * wx;
 end  % for jj
 rr = rAv;
 if j < n
  mn = norm(rr(j+1:n));
 else
  mn = 0;
 end % if j
 if mn  ~= 0
  if j+1 <= n
   w(1:j) = zeros(j,1);
   w(j+1:n) = rr(j+1:n);
   mi = norm(w);
   if mi  ~=0  && j+1 < n
    beta = w(j+1) + sign(w(j+1)) * mi;
    if abs(beta) <= eps
     beta = w(j+1) - sign(w(j+1)) * mi;
    end % if abs
    if abs(beta) <= eps  % sign(0) = 0 in Matlab
     beta = -mi;
    end % if abs
    w(j+2:n) = w(j+2:n) ./ beta;
   end  % if mi
   w(j+1) = 1;
   wtr = w' * rr;
   rr = rr - 2 * (wtr / (w' * w)) * w;
  end  % if j+1
 else
  w = zeros(n,1);
 end  % if mn
 W(:,j+1) = w;
 ww(j+1) = w' * w;
 if j <= n-1
  H(1:j+1,j) = rr(1:j+1);
 else
  H(1:m,m) = rr(1:m);
 end % if j
 if j < n
  if ww(j+1) > 0
   ej1 = zeros(n,1);
   ej1(j+1) = 1;
   we = ej1 - 2 * (w(j+1) / ww(j+1)) * w;
   for jj = j:-1:1 % apply the preceding Householder reflections
    wx = W(:,jj);
    wte = wx' * we;
    we = we - 2 * (wte / ww(jj)) * wx;
   end % for jj
  else
   error(' Problem in K Arnoldi Householder') % error
  end  % if ww
  V(:,j+1) = we;
 end % if j
end  % for j


