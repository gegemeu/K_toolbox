function [x,ni,bresn] = K_QMR_3t(A,b,x0,w0,epsi,nitmax);
%K_QMR_3T QMR 3-term recurrences without look-ahead

% A, b = matrix and right-hand side
% x0 = starting vector
% w0 = shadow vector
% epsi = stopping threshold
% nitmax = maximum number of iterations
% x = approximate solution
% ni = number of iterations
% bresn = upper bound of the residual norms 

n = size(A,1);
bresn = zeros(1,nitmax);
trid = zeros(nitmax+1,nitmax+1);
rot = zeros(2,nitmax);
v = b;
nb = norm(b);
nr0 = norm(v);
v = v / nr0;
if norm(w0) == 0
 w0 = b;
end
if ~isempty(w0)
 w = w0 / norm(w0);
else
 w = v;
end % if
wv = transpose(w) * v;
wv_old = wv;
v1 = zeros(n,1);
w1 = v1;
ss = zeros(n,1);
ss(1) = nr0;
At = transpose(A);
r = b - A * x0;
x = x0;
bresn(1) = norm(r);
prods = 1;
ni = 0;

for k = 1:nitmax
 ni = ni + 1;
 Av = A * v;
 Aw = At * w;
 alpha = (transpose(w) * Av) / wv;
 beta = (transpose(w1) * Av) / wv_old;
 vt = Av - alpha * v - beta * v1;
 gamma = (transpose(v1) * Aw) / wv_old;
 wt = Aw - alpha * w - gamma * w1;
 rho = norm(vt);
 zeta = norm(wt);
 v1 = v;
 w1 = w;
 v = vt / rho;
 w = wt / zeta; 
 wv_new = transpose(w) * v;
 wv_old = wv;
 wv = wv_new;
 trid(k,k) = alpha;
 trid(k+1,k) = rho;
 if k > 1
  trid(k-1,k) = beta;
 end
 % apply the two preceding rotations to column k
 for l = max(k-2,1):k-1
  t1 = trid(l,k);
  t2 = trid(l+1,k);
  trid(l,k) = rot(1,l) * t1 - rot(2,l) * t2;
  trid(l+1,k) = rot(2,l)* t1 + rot(1,l) * t2;
 end % for l
 % compute store and apply rotation to zero the entry (k+1,k)
 tk = trid(k,k);
 cs = sqrt(trid(k+1,k)^2 + tk^2);
 rot(1,k) = tk / cs; % cosine
 rot(2,k) = -trid(k+1,k) / cs; % sine
 prods = prods * abs(rot(2,k));
 trid(k,k) = cs;
 c = ss(k) / cs;
 ss(k) = tk * c;
 ss(k+1) = -trid(k+1,k) * c;
 trid(k+1,k) = 0;
 switch k
  case 1
   p = v1 / trid(1,1);
   p1 = p;
  case 2
   p_old = p;
   p = (v1 - trid(1,2) * p1) / trid(2,2);
   p1 = p_old;
  otherwise
   p_old = p;
   p = (v1 - trid(k-1,k) * p - trid(k-2,k) * p1) / trid(k,k);
   p1 = p_old;
 end % switch k
 x = x + ss(k) * p;
 nresidu = sqrt(k+1) * prods;
 bresn(ni+1) = nb * nresidu;
 if nresidu < (epsi * nb) || ni >= nitmax
  if norm(b - A * x) < (epsi * nb) % check the true residual norm
   break  % get out of the k loop
  end % if norm
 end  % if nresidu
end % for k
bresn = bresn(1:ni+1);






