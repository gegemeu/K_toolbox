function [V,W,T,P,Q] = K_biortho_2t(A,v,w,nitmax);
%K_BIORTHO_2T Biorthogonal basis with 2-term recurrences

% Basis vectors of unit norm
% This works only for real data

% A = matrix
% v, w = starting vectors
% nitmax iterations
% V, W = basis vectors
% P, Q = direction vectors
% T = tridiagonal matrices

v = v / norm(v);
w = w / norm(w);
n = size(A,1);
p = v;
q = w;
T = sparse(nitmax,nitmax);
V = zeros(n,nitmax);
W = zeros(n,nitmax);
P = zeros(n,nitmax);
Q = zeros(n,nitmax);
At = A';
Ap = A * p;
Atq = At * q;
alpha = v' * w;
delta = Ap' * q;

for k = 1:nitmax 
 V(:,k) = v;
 W(:,k) = w;
 P(:,k) = p;
 Q(:,k) = q;
 phi = delta / alpha;
 vt = Ap - phi * v;
 wt = Atq - phi * w;
 rho = norm(vt);
 zeta = norm(wt);
 v = vt / rho;
 w = wt / zeta;
 alpha = v' * w;
% check the breakdowns
 if abs(alpha) < 1e-13 
  fprintf('\n K biortho_2t: Near breakdown step %d, alpha = %12.5e \n',k,alpha)
 end % if
 if abs(delta) < 1e-13 
  fprintf('\n K biortho_2t: Near breakdown step %d, delta = %12.5e \n',k,full(delta))
 end % if
 psi = zeta * alpha / delta;
 psit = rho * alpha / delta;
 p = v - psi * p;
 q = w - psit * q;
 Ap = A * p;
 Atq = At * q;
 delta = Ap' * q;
 T(k,k) = 1;
 T(k,k+1) = 0;
 T(k+1,k) = 0;
end % for k
T = T(1:nitmax,1:nitmax);

